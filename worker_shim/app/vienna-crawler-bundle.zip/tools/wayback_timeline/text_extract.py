"""HTML -> plain text, with one specific lesson baked in from the pilot: a
naive tag-strip runs nav menus and sentences together into one undifferentiated
blob, which made genuinely strong evidence ("Shop On-line" as its own link)
look like an ambiguous fragment to the model. Block-level tags become line
breaks here instead, so a short nav label stays visually distinct from a full
sentence — it doesn't fix every case, but it keeps the signal the source HTML
actually had instead of destroying it before the model ever sees it.
"""
from __future__ import annotations

import re
import unicodedata

_SCRIPT_STYLE_RE = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL)
_BLOCK_TAG_RE = re.compile(
    r"</?(p|div|br|li|ul|ol|table|tr|td|th|h[1-6]|nav|header|footer|section|article)\b[^>]*>",
    re.IGNORECASE,
)
_ANY_TAG_RE = re.compile(r"<[^>]+>")
_BLANK_LINES_RE = re.compile(r"\n\s*\n+")
_TRAILING_SPACE_RE = re.compile(r"[ \t]+")


def html_to_text(html: str) -> str:
    text = _SCRIPT_STYLE_RE.sub(" ", html)
    text = _BLOCK_TAG_RE.sub("\n", text)
    text = _ANY_TAG_RE.sub(" ", text)
    text = unicodedata.normalize("NFKC", text)
    text = _TRAILING_SPACE_RE.sub(" ", text)
    text = _BLANK_LINES_RE.sub("\n", text)
    lines = [ln.strip() for ln in text.split("\n")]
    lines = [ln for ln in lines if ln]
    return "\n".join(lines)
