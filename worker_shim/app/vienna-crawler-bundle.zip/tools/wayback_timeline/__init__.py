"""Standalone, opportunistic enrichment: reads a company's Wayback Machine
history and finds the earliest point certain claims appear on its homepage.
Never wired into digital-maturity-crawler or any other crawler in this repo
— it only ever queries the public Wayback CDX API directly, and writes to
its own output folder. See README.md for the architecture and why the model
is only ever asked to retrieve a quote, never to judge true/false.
"""
