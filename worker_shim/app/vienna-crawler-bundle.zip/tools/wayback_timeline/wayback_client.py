"""Wayback Machine access: CDX query + raw snapshot fetch.

Mirrors the exact approach crawlers/digital-maturity-crawler/src/wayback/cdx.ts
already verified live (same query shape, same id_ snapshot-URL trick to avoid
Wayback's own toolbar injection, same courtesy-delay philosophy) — ported to
Python rather than importing across repos, since this tool must work even
when that crawler isn't present or hasn't been touched.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from urllib.parse import urlencode

USER_AGENT = "ProjectViennaBot/1.0 (wayback-timeline tool; contact gio3maz@gmail.com)"
CDX_ENDPOINT = "http://web.archive.org/cdx/search/cdx"

# More conservative than digital-maturity-crawler's 800ms default: this tool
# fetches far more snapshots per company, so "I have time" should mean
# "extra polite to a nonprofit's infrastructure," not "hit it harder."
WAYBACK_DELAY_S = 2.0
CDX_RETRIES = 3


@dataclass
class Capture:
    timestamp: str  # YYYYMMDDhhmmss
    original: str

    @property
    def date_str(self) -> str:
        return f"{self.timestamp[:4]}-{self.timestamp[4:6]}-{self.timestamp[6:8]}"

    @property
    def raw_snapshot_url(self) -> str:
        # The id_ suffix returns the original, unmodified bytes — verified
        # live by digital-maturity-crawler (matches x-archive-orig-content-
        # length exactly), unlike the plain /web/{timestamp}/{url} pattern
        # which injects Wayback's own toolbar JS/CSS into the page.
        return f"https://web.archive.org/web/{self.timestamp}id_/{self.original}"

    @property
    def replay_url(self) -> str:
        return f"https://web.archive.org/web/{self.timestamp}/{self.original}"


def query_cdx(url: str) -> list[Capture]:
    """One capture per calendar day (collapse=timestamp:8), 200s only —
    same filter digital-maturity-crawler uses, same accepted limitation:
    this is an exact-URL-key match, not a domain-wide crawl, so results can
    be sparse or stop earlier than the site's real lifetime. That's the
    project's existing, documented tradeoff, not a bug in this tool."""
    params = urlencode({
        "url": url, "output": "json", "collapse": "timestamp:8",
        "filter": "statuscode:200", "fl": "timestamp,original",
    })
    req = urllib.request.Request(f"{CDX_ENDPOINT}?{params}", headers={"User-Agent": USER_AGENT})

    last_error: Exception | None = None
    for attempt in range(CDX_RETRIES + 1):
        if attempt > 0:
            time.sleep(min(2 * 2 ** attempt, 30))  # 4s, 8s, 16s — a 503 is the archive asking for a pause
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read().decode("utf-8")
            if not body.strip():
                return []
            rows = json.loads(body)
            return [Capture(timestamp=r[0], original=r[1]) for r in rows[1:]]
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as e:
            last_error = e
    raise RuntimeError(f"CDX query failed after {CDX_RETRIES + 1} attempts: {last_error}")


def fetch_raw_snapshot(capture: Capture) -> str:
    """Courtesy delay applies here too (every request to web.archive.org,
    not just CDX queries)."""
    time.sleep(WAYBACK_DELAY_S)
    req = urllib.request.Request(capture.raw_snapshot_url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read().decode("utf-8", errors="replace")
