"""Shared RAM/time/stop-file guard. Identical to the one built for the
Verdantex evidence harvester (ported, not imported, for the same reason as
gate.py) — checked before the job starts and between every snapshot, so an
unattended multi-hour run refuses to run the model into a starved machine
and stops cleanly on a STOP file or its time budget, not mid-crash.
"""
from __future__ import annotations

import ctypes
import time
from dataclasses import dataclass
from pathlib import Path


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def free_ram_gb() -> float:
    stat = _MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))  # type: ignore[attr-defined]
    return stat.ullAvailPhys / (1024 ** 3)


class RamTooLowError(RuntimeError):
    def __init__(self, free_gb: float, threshold_gb: float):
        super().__init__(f"free RAM {free_gb:.2f} GB below the {threshold_gb:.2f} GB gate")
        self.free_gb = free_gb
        self.threshold_gb = threshold_gb


class StoppedError(RuntimeError):
    def __init__(self, stop_file: Path):
        super().__init__(f"stop file present: {stop_file}")


@dataclass
class JobGuard:
    output_dir: Path
    max_minutes: float = 480.0  # generous default: this job is meant to run for hours
    min_free_gb: float = 2.0
    _start: float = 0.0

    def __post_init__(self) -> None:
        self.output_dir = Path(self.output_dir)
        self._start = time.monotonic()

    @property
    def stop_file(self) -> Path:
        return self.output_dir / "STOP"

    def elapsed_minutes(self) -> float:
        return (time.monotonic() - self._start) / 60.0

    def check(self) -> None:
        if self.stop_file.exists():
            raise StoppedError(self.stop_file)
        if self.elapsed_minutes() >= self.max_minutes:
            raise TimeoutError(f"max_minutes {self.max_minutes} reached")
        free = free_ram_gb()
        if free < self.min_free_gb:
            raise RamTooLowError(free, self.min_free_gb)

    def ok(self) -> bool:
        try:
            self.check()
            return True
        except (StoppedError, TimeoutError, RamTooLowError):
            return False
