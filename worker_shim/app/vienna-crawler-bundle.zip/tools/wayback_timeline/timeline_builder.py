"""Orchestrates the whole pass: for each company and each claim, walk its
Wayback snapshots oldest to newest, ask the model for a quote, verify it
with the gate, and stop at the first confirmed hit (no need to keep
checking later snapshots once a claim's earliest appearance is found).

Run by hand, whenever, for however long: no scheduler, no cron, nothing
else in this repo depends on this ever running.

    python -m tools.wayback_timeline.timeline_builder --input data/sample-companies.csv

Resumable: a state file in the output dir tracks exactly which snapshots
have already been checked for each (company, claim) pair, so stopping the
process (closing the laptop, a STOP file, running out of time budget) and
running it again later picks up exactly where it left off — no duplicate
model calls, no duplicate network fetches.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
import atexit
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from tools.wayback_timeline.gate import quote_verified
from tools.wayback_timeline.model_client import ask_for_quote
from tools.wayback_timeline.ram_guard import JobGuard, RamTooLowError, StoppedError
from tools.wayback_timeline.text_extract import html_to_text
from tools.wayback_timeline.wayback_client import Capture, fetch_raw_snapshot, query_cdx

REPO_ROOT = Path(__file__).resolve().parents[2]
# Deliberately NOT under REPO_ROOT or anywhere in OneDrive: this tool writes
# its state file after nearly every snapshot (far more often than a typical
# crawl output write), and OneDrive's sync engine reacting to every single
# one of those writes was a real, measured contributor to RAM pressure
# during the pilot. A local-only path avoids that feedback loop entirely.
DEFAULT_OUTPUT_DIR = Path.home() / "WaybackTimelineOutput"

# Fixed, small, explicit — classification-shaped claims, not open-ended
# extraction, matching what the pilot showed this model actually handles.
CLAIMS: dict[str, str] = {
    "online_store": "an online store or e-commerce checkout (customers can buy products directly on this website)",
    "sustainability_commitment": "a stated sustainability, environmental, or carbon-reduction commitment",
    "certification_or_award": "a specific named certification, award, or official recognition",
}

# Sample roughly this often across a company's full capture history.
SAMPLE_INTERVAL_MONTHS = 6


@dataclass
class Hit:
    timestamp: str
    date: str
    quote: str
    replay_url: str


def load_companies(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def sample_captures(captures: list[Capture], interval_months: int) -> list[Capture]:
    if not captures:
        return []
    out = [captures[0]]
    last_ts = captures[0].timestamp[:6]  # YYYYMM
    for cap in captures[1:]:
        ym = cap.timestamp[:6]
        months_apart = (int(ym[:4]) - int(last_ts[:4])) * 12 + (int(ym[4:6]) - int(last_ts[4:6]))
        if months_apart >= interval_months:
            out.append(cap)
            last_ts = ym
    if out[-1].timestamp != captures[-1].timestamp:
        out.append(captures[-1])
    return out


class State:
    def __init__(self, path: Path):
        self.path = path
        self.data: dict = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}

    def key(self, company_id: str, claim_id: str) -> str:
        return f"{company_id}::{claim_id}"

    def entry(self, company_id: str, claim_id: str) -> dict:
        return self.data.setdefault(self.key(company_id, claim_id), {
            "done": False, "checked_timestamps": [], "first_hit": None,
        })

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")


def process_company_claim(
    company_id: str, homepage_url: str, claim_id: str, claim_desc: str,
    state: State, results_path: Path, guard: JobGuard,
) -> None:
    entry = state.entry(company_id, claim_id)
    if entry["done"]:
        return

    print(f"[{company_id} / {claim_id}] querying CDX for {homepage_url} ...", flush=True)
    try:
        captures = query_cdx(homepage_url)
    except Exception as e:
        print(f"  CDX query failed, leaving for next run: {e}", flush=True)
        return
    sampled = sample_captures(captures, SAMPLE_INTERVAL_MONTHS)
    print(f"  {len(captures)} total captures, {len(sampled)} sampled", flush=True)

    for cap in sampled:
        if cap.timestamp in entry["checked_timestamps"]:
            continue
        guard.check()  # raises if RAM is too low / time is up / STOP file present

        print(f"  [{cap.date_str}] fetching snapshot...", flush=True)
        try:
            html = fetch_raw_snapshot(cap)
        except Exception as e:
            print(f"    fetch failed, will retry next run: {e}", flush=True)
            continue  # don't mark as checked — retry it next time
        text = html_to_text(html)
        if not text:
            entry["checked_timestamps"].append(cap.timestamp)
            state.save()
            continue

        call = ask_for_quote(claim_desc, text)
        print(f"    model: {call.wall_seconds}s, quote={call.quote!r}", flush=True)
        entry["checked_timestamps"].append(cap.timestamp)

        if call.parse_ok and quote_verified(call.quote, text):
            hit = Hit(timestamp=cap.timestamp, date=cap.date_str, quote=call.quote, replay_url=cap.replay_url)
            entry["first_hit"] = asdict(hit)
            entry["done"] = True
            state.save()
            with results_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"company_id": company_id, "claim_id": claim_id, **asdict(hit)}) + "\n")
            print(f"  ==> CONFIRMED first hit at {cap.date_str}: {cap.replay_url}", flush=True)
            return
        state.save()

    entry["done"] = True  # exhausted every sampled snapshot, no confirmed hit
    state.save()
    print(f"  no confirmed hit across {len(sampled)} sampled snapshots", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="CSV with company_id, homepage_url")
    ap.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    ap.add_argument("--max-minutes", type=float, default=480.0)
    ap.add_argument("--min-free-gb", type=float, default=2.0)
    ap.add_argument("--claims", default=None, help="comma-separated claim ids, default: all")
    args = ap.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # A PID file, written for the life of this process, so anything else on
    # this same machine (e.g. a settings panel) can answer "is it running
    # right now" without guessing. Removed on any exit path, clean or not.
    pid_file = output_dir / "running.pid"
    pid_file.write_text(str(os.getpid()), encoding="utf-8")
    atexit.register(lambda: pid_file.unlink(missing_ok=True))

    state = State(output_dir / "state.json")
    results_path = output_dir / "timeline_hits.jsonl"
    guard = JobGuard(output_dir=output_dir, max_minutes=args.max_minutes, min_free_gb=args.min_free_gb)

    companies = load_companies(Path(args.input))
    claim_ids = args.claims.split(",") if args.claims else list(CLAIMS.keys())

    print(f"{len(companies)} companies x {len(claim_ids)} claims. Output: {output_dir}", flush=True)
    print(f"Stop anytime with a STOP file in {output_dir}, or just close the terminal — progress is saved per snapshot.", flush=True)

    try:
        for company in companies:
            for claim_id in claim_ids:
                guard.check()
                process_company_claim(
                    company["company_id"], company["homepage_url"],
                    claim_id, CLAIMS[claim_id], state, results_path, guard,
                )
    except StoppedError:
        print("Stopped via STOP file. Progress saved; run again to resume.", flush=True)
    except TimeoutError:
        print(f"Time budget ({args.max_minutes} min) reached. Progress saved; run again to resume.", flush=True)
    except RamTooLowError as e:
        print(f"Refusing to continue: {e}. Progress saved; run again when more RAM is free.", flush=True)


if __name__ == "__main__":
    sys.exit(main())
