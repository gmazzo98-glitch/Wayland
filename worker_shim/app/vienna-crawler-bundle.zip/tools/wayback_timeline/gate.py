"""The deterministic check. The model proposes a quote; this decides
whether it's real. Ported from the same normalize/verify approach built and
stress-tested for the Verdantex evidence harvester (whitespace/unicode/
hyphenation-insensitive substring check, with a hyphen-tolerant fallback for
PDF/HTML line-wrap artifacts) — copied rather than imported across repos, so
this tool has no dependency on another project's code ever being present.
"""
from __future__ import annotations

import re
import unicodedata

_QUOTE_CHARS = {
    "‘": "'", "’": "'", "‚": "'", "′": "'",
    "“": '"', "”": '"', "„": '"', "″": '"',
}
# Non-breaking hyphen, various dash widths, soft hyphen: typography choices
# in real HTML, not equivalent to a line-wrap artifact (see _HYPHEN_BREAK
# below) — these are just a different character meaning the same hyphen.
_DASH_CHARS = "‐‑‒–—―­"
_HYPHEN_BREAK = re.compile(r"([A-Za-z])-\s*\n\s*([a-z])")


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    for src, dst in _QUOTE_CHARS.items():
        text = text.replace(src, dst)
    for ch in _DASH_CHARS:
        text = text.replace(ch, "-")
    text = _HYPHEN_BREAK.sub(r"\1\2", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text.lower()


def quote_verified(quote: str | None, source_text: str) -> bool:
    """True only if `quote` is a verbatim (whitespace/unicode/hyphenation-
    insensitive) substring of `source_text`. A model paraphrase, or a quote
    about the right topic but wrong wording, fails this — on purpose."""
    if not quote or not quote.strip():
        return False
    nq = normalize_text(quote)
    nt = normalize_text(source_text)
    if nq in nt:
        return True
    # Hyphen-tolerant fallback: a line-wrap hyphen is ambiguous about
    # whether the original word had one at all (see Verdantex gate.py for
    # the full story) — a one-character difference here is not a paraphrase.
    nq_h, nt_h = nq.replace("-", ""), nt.replace("-", "")
    return bool(nq_h) and nq_h in nt_h
