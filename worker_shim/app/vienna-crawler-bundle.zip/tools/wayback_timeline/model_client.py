"""Local Ollama client. One lesson from the pilot is load-bearing here: the
model is asked for a quote-or-null only, never a true/false judgment — when
it was also asked to classify, it returned a verbatim, correct supporting
quote and STILL labelled it false (and, with an unconstrained schema, null)
more than once. Retrieval is reliable; its own judgment on top of that
retrieval is not. So the model proposes a quote; the gate (see gate.py)
is what decides.
"""
from __future__ import annotations

import json
import time
import urllib.request
from dataclasses import dataclass
from typing import Any, Optional

DEFAULT_ENDPOINT = "http://localhost:11434"
DEFAULT_MODEL = "qwen2.5-3b-8k"
DEFAULT_NUM_CTX = 8192

QUOTE_ONLY_SCHEMA = {
    "type": "object",
    "properties": {"quote": {"type": ["string", "null"]}},
    "required": ["quote"],
}


@dataclass
class QuoteCallResult:
    quote: Optional[str]
    parse_ok: bool
    raw_response: str
    prompt_eval_count: int
    eval_count: int
    wall_seconds: float


def ask_for_quote(
    claim_description: str,
    page_text: str,
    *,
    model: str = DEFAULT_MODEL,
    endpoint: str = DEFAULT_ENDPOINT,
    num_ctx: int = DEFAULT_NUM_CTX,
    max_text_chars: int = 6000,
    timeout_s: float = 300.0,
) -> QuoteCallResult:
    prompt = (
        f"Find a verbatim excerpt from the text below that states the company has "
        f"{claim_description}.\n"
        "If no such excerpt exists in this text, return null. Copy exactly, never "
        "paraphrase, never guess, never infer from general knowledge about the company "
        "— only from what this specific text actually says.\n\n"
        f"Text:\n{page_text[:max_text_chars]}"
    )
    payload = {
        "model": model, "prompt": prompt, "stream": False,
        "format": QUOTE_ONLY_SCHEMA, "options": {"temperature": 0, "num_ctx": num_ctx},
    }
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        f"{endpoint}/api/generate", data=body,
        headers={"Content-Type": "application/json"}, method="POST",
    )
    t0 = time.monotonic()
    with urllib.request.urlopen(req, timeout=timeout_s) as resp:
        data: dict[str, Any] = json.loads(resp.read().decode("utf-8"))
    wall = time.monotonic() - t0

    raw_text = data.get("response", "")
    try:
        parsed = json.loads(raw_text)
        quote = parsed.get("quote")
        parse_ok = True
    except json.JSONDecodeError:
        quote = None
        parse_ok = False

    return QuoteCallResult(
        quote=quote, parse_ok=parse_ok, raw_response=raw_text,
        prompt_eval_count=data.get("prompt_eval_count", 0),
        eval_count=data.get("eval_count", 0),
        wall_seconds=wall,
    )
