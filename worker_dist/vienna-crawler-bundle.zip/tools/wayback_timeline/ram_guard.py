"""Shared RAM/time/stop-file guard. Identical to the one built for the
Verdantex evidence harvester (ported, not imported, for the same reason as
gate.py) — checked before the job starts and between every snapshot, so an
unattended multi-hour run never runs the model into a starved machine and
stops cleanly on a STOP file or its time budget, not mid-crash.

Low RAM waits rather than aborting: the first real deployment showed this
mattered in practice, not just in theory. A machine can easily be briefly
over the gate when Start is clicked (another app mid-launch, a browser tab
settling) and have room again a minute later — exiting outright on that one
reading turned an hours-long, meant-to-be-unattended job into something that
silently died in under ten seconds and needed a human to notice and retry.
Since this job already tolerates being stopped and resumed at any point
(state.json), waiting here costs nothing but time, which this job already
has a generous budget for, and stays bounded by that same budget and by the
STOP file either way.
"""
from __future__ import annotations

import ctypes
import time
from dataclasses import dataclass
from pathlib import Path


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def free_ram_gb() -> float:
    stat = _MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))  # type: ignore[attr-defined]
    return stat.ullAvailPhys / (1024 ** 3)


class RamTooLowError(RuntimeError):
    def __init__(self, free_gb: float, threshold_gb: float):
        super().__init__(f"free RAM {free_gb:.2f} GB below the {threshold_gb:.2f} GB gate")
        self.free_gb = free_gb
        self.threshold_gb = threshold_gb


class StoppedError(RuntimeError):
    def __init__(self, stop_file: Path):
        super().__init__(f"stop file present: {stop_file}")


@dataclass
class JobGuard:
    output_dir: Path
    max_minutes: float = 480.0  # generous default: this job is meant to run for hours
    min_free_gb: float = 2.0
    ram_wait_seconds: float = 60.0  # how often to recheck while waiting for RAM to free up
    _start: float = 0.0

    def __post_init__(self) -> None:
        self.output_dir = Path(self.output_dir)
        self._start = time.monotonic()

    @property
    def stop_file(self) -> Path:
        return self.output_dir / "STOP"

    def elapsed_minutes(self) -> float:
        return (time.monotonic() - self._start) / 60.0

    def check(self) -> None:
        waited = False
        while True:
            if self.stop_file.exists():
                raise StoppedError(self.stop_file)
            if self.elapsed_minutes() >= self.max_minutes:
                raise TimeoutError(f"max_minutes {self.max_minutes} reached")
            free = free_ram_gb()
            if free >= self.min_free_gb:
                if waited:
                    print(f"  RAM freed up ({free:.2f} GB) — continuing.", flush=True)
                return
            waited = True
            print(f"  waiting for RAM: {free:.2f} GB free, need {self.min_free_gb:.2f} GB "
                  f"(rechecking every {self.ram_wait_seconds:.0f}s)", flush=True)
            time.sleep(self.ram_wait_seconds)

    def ok(self) -> bool:
        try:
            self.check()
            return True
        except (StoppedError, TimeoutError, RamTooLowError):
            return False
