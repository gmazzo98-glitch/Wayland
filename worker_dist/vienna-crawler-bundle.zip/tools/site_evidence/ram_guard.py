"""RAM / time / stop-file guard for a job that is meant to run for days.

Lesson from tools/wayback_timeline/ram_guard.py that this version fixes: that guard waited
until a fixed 2 GB was free. But once the local model is loaded it occupies ~2.5 GB of an
8 GB machine, so free RAM sits at ~1 GB for as long as the model stays loaded, and a guard
that insists on 2 GB then waits forever (the old tool only ever got through because Ollama
unloaded the model after 5 idle minutes, by accident). So there are two thresholds here:

  - the model is NOT loaded: loading it needs real headroom (`min_free_gb_to_load`);
  - the model IS loaded: its memory is already paid for, so only a low floor
    (`min_free_gb_loaded`) protects the rest of the machine from swapping.

Waiting never aborts the job: it is resumable anyway, so it costs nothing but time, and it
stays bounded by `max_minutes` and by the STOP file.
"""
from __future__ import annotations

import ctypes
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def free_ram_gb() -> float:
    if sys.platform == "win32":
        stat = _MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))  # type: ignore[attr-defined]
        return stat.ullAvailPhys / (1024 ** 3)
    try:  # Linux, for tests and CI
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / (1024 ** 2)
    except OSError:
        pass
    return 99.0  # unknown platform: do not block


class StoppedError(RuntimeError):
    def __init__(self, stop_file: Path):
        super().__init__(f"stop file present: {stop_file}")


class TimeBudgetError(RuntimeError):
    def __init__(self, max_minutes: float):
        super().__init__(f"time budget of {max_minutes:g} minutes reached")


@dataclass
class JobGuard:
    output_dir: Path
    max_minutes: float = 0.0  # 0 = no time limit (the supervisor and STOP file still apply)
    min_free_gb_to_load: float = 2.0
    min_free_gb_loaded: float = 0.5
    ram_wait_seconds: float = 60.0
    free_ram: Callable[[], float] = field(default=free_ram_gb)
    sleep: Callable[[float], None] = field(default=time.sleep)
    _start: float = 0.0

    def __post_init__(self) -> None:
        self.output_dir = Path(self.output_dir)
        self._start = time.monotonic()

    @property
    def stop_file(self) -> Path:
        return self.output_dir / "STOP"

    def elapsed_minutes(self) -> float:
        return (time.monotonic() - self._start) / 60.0

    def check_stop_and_time(self) -> None:
        if self.stop_file.exists():
            raise StoppedError(self.stop_file)
        if self.max_minutes and self.elapsed_minutes() >= self.max_minutes:
            raise TimeBudgetError(self.max_minutes)

    def check(self, model_loaded: bool = False, on_wait: Optional[Callable[[str], None]] = None) -> None:
        """Returns when it is fine to run one more model call; raises StoppedError or
        TimeBudgetError when the job must end. Never raises for low RAM, it waits."""
        need = self.min_free_gb_loaded if model_loaded else self.min_free_gb_to_load
        waited = False
        while True:
            self.check_stop_and_time()
            free = self.free_ram()
            if free >= need:
                if waited and on_wait:
                    on_wait(f"RAM freed up ({free:.2f} GB free) - continuing.")
                return
            waited = True
            if on_wait:
                state = "model loaded" if model_loaded else "model not loaded"
                on_wait(f"waiting for RAM: {free:.2f} GB free, need {need:.2f} GB ({state}); "
                        f"rechecking in {self.ram_wait_seconds:.0f}s")
            self.sleep(self.ram_wait_seconds)
