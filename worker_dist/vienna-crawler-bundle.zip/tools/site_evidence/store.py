"""On-disk state that survives crashes, power cuts and OneDrive-style interference.

The Wayback tool wrote state.json with Path.write_text(): a crash or power cut mid-write
leaves a truncated file, the next start fails to parse it, and a multi-day job is dead until a
human notices. Everything here is written atomically instead (temp file in the same folder, then
os.replace), the previous good version is kept as `.bak`, and a corrupt file falls back to that
backup rather than raising. Append-only logs tolerate a torn last line.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, Optional


def atomic_write_json(path: Path, data: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, indent=1, ensure_ascii=False)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        if path.exists():
            try:
                os.replace(path, path.with_name(path.name + ".bak"))
            except OSError:
                pass  # a locked backup must never block saving the new state
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load_json_with_backup(path: Path, default: Any) -> Any:
    """The file, else its .bak, else `default`. A corrupt primary is moved aside, not deleted."""
    path = Path(path)
    for candidate in (path, path.with_name(path.name + ".bak")):
        if not candidate.exists():
            continue
        try:
            return json.loads(candidate.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            if candidate == path:
                try:
                    os.replace(path, path.with_name(path.name + ".corrupt"))
                except OSError:
                    pass
    return default


def append_jsonl(path: Path, record: Dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(record, ensure_ascii=False) + "\n"
    with path.open("a", encoding="utf-8") as fh:
        fh.write(line)
        fh.flush()
        os.fsync(fh.fileno())


def read_jsonl(path: Path) -> Iterator[Dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        return
    with path.open(encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except ValueError:
                continue  # a torn last line from a crash; everything before it is still good


class State:
    """Per-company progress: {company_id: record}. Saved after every company."""

    def __init__(self, path: Path):
        self.path = Path(path)
        data = load_json_with_backup(self.path, {})
        self.data: Dict[str, Dict[str, Any]] = data if isinstance(data, dict) else {}

    def get(self, company_id: str) -> Optional[Dict[str, Any]]:
        return self.data.get(company_id)

    def put(self, company_id: str, record: Dict[str, Any]) -> None:
        self.data[company_id] = record
        atomic_write_json(self.path, self.data)


class LlmCache:
    """Every model answer, keyed by (model, claim, passage). A crash in the middle of a
    company, or a re-run, never pays for the same call twice."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._mem: Dict[str, Optional[str]] = {}
        for row in read_jsonl(self.path):
            if "k" in row:
                self._mem[row["k"]] = row.get("quote")

    @staticmethod
    def key(model: str, claim_id: str, passage: str) -> str:
        return hashlib.sha1(f"{model}\x00{claim_id}\x00{passage}".encode("utf-8")).hexdigest()

    def has(self, k: str) -> bool:
        return k in self._mem

    def get(self, k: str) -> Optional[str]:
        return self._mem.get(k)

    def put(self, k: str, quote: Optional[str]) -> None:
        self._mem[k] = quote
        append_jsonl(self.path, {"k": k, "quote": quote})

    def __len__(self) -> int:
        return len(self._mem)
