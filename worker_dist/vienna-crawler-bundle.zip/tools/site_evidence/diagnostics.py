"""Everything needed to understand why a run is slow, stuck or failed, in one JSON document.

    python -m tools.site_evidence.diagnostics [--output-dir <folder>] [--zip <file.zip>]

It reads only files and probes the local model server, so it works with the PC offline, with the
Vienna app unreachable and with the supervisor dead. The Vienna worker calls the same function when
the app asks for diagnostics and when a run fails, and attaches the result to the audit trail.

Nothing secret is collected: no tokens, no environment variables, no page text beyond the quotes the
tool already stores.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional

from .buildinfo import environment
from .events import clip, now_iso
from .ollama import OllamaClient, find_ollama_exe
from .procutil import pid_alive
from .ram_guard import free_ram_gb
from .store import load_json_with_backup, read_jsonl

PROBLEM_STATUSES = {"partial", "site_unreachable", "bad_homepage", "blocked", "robots_blocked", "no_website"}


def tail_file(path: Path, max_lines: int = 300, max_bytes: int = 400_000) -> List[str]:
    try:
        size = path.stat().st_size
        with path.open("rb") as fh:
            fh.seek(max(0, size - max_bytes))
            data = fh.read()
    except OSError:
        return []
    return data.decode("utf-8", errors="replace").splitlines()[-max_lines:]


def _pid(path: Path) -> int:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return 0


def _json(path: Path) -> Any:
    return load_json_with_backup(path, None)


def collect(out: Path, tail_lines: int = 300, events_tail: int = 200) -> Dict[str, Any]:
    out = Path(out)
    state = _json(out / "state.json")
    state = state if isinstance(state, dict) else {}
    sup_pid, run_pid = _pid(out / "supervisor.pid"), _pid(out / "runner.pid")

    statuses = Counter(rec.get("status") for rec in state.values())
    problems = []
    for cid, rec in state.items():
        if rec.get("status") in PROBLEM_STATUSES or rec.get("error"):
            problems.append({
                "company_id": cid, "name": rec.get("name"), "status": rec.get("status"),
                "attempts": rec.get("attempts"), "detail": rec.get("site_detail") or rec.get("error"),
                "pages_failed": (rec.get("pages_failed") or [])[:5], "homepage_url": rec.get("homepage_url"),
                "finished_at": rec.get("finished_at"),
            })
    problems.sort(key=lambda p: (p["status"] != "partial", str(p["status"]), str(p["name"])))

    events = list(read_jsonl(out / "events.jsonl"))
    by_level = Counter(e.get("level") for e in events)
    by_code = Counter(e.get("code") for e in events)
    recent_bad = [e for e in events if e.get("level") in ("warn", "error")][-60:]

    ollama = OllamaClient()
    tags = ollama.tags()
    ps = ollama.loaded()

    outbox = out / "outbox.jsonl"
    cursor = _json(out / "report_cursor.json") or {}
    backlog = max(0, (outbox.stat().st_size if outbox.exists() else 0) - int(cursor.get("outbox_offset", 0)))
    try:
        disk = shutil.disk_usage(out if out.exists() else out.parent)
        disk_info = {"free_gb": round(disk.free / 1024 ** 3, 2), "total_gb": round(disk.total / 1024 ** 3, 2)}
    except OSError as e:
        disk_info = {"error": str(e)}

    files = {}
    for name in ("state.json", "results.jsonl", "outbox.jsonl", "events.jsonl", "llm_cache.jsonl", "run.log",
                 "supervisor.log", "heartbeat.json", "progress.json", "control.json", "report_cursor.json",
                 "report_status.json", "quarantine.jsonl", "supervisor_exit.json", "run_summary.json"):
        p = out / name
        if p.exists():
            files[name] = {"bytes": p.stat().st_size, "modified": int(p.stat().st_mtime)}

    return clip(max_items=400, max_string=4000, max_depth=7, value={
        "generated_at": now_iso(),
        "environment": environment(),
        "output_dir": str(out),
        "resources": {"free_ram_gb": round(free_ram_gb(), 2), "disk": disk_info},
        "model_server": {
            "executable_found": bool(find_ollama_exe()), "reachable": tags is not None, "models": tags,
            "loaded_now": [m.get("name") for m in (ps or [])],
        },
        "processes": {
            "supervisor_pid": sup_pid, "supervisor_alive": bool(sup_pid and pid_alive(sup_pid)),
            "runner_pid": run_pid, "runner_alive": bool(run_pid and pid_alive(run_pid)),
            "stop_file_present": (out / "STOP").exists(),
        },
        "control": _json(out / "control.json"),
        "progress": _json(out / "progress.json"),
        "heartbeat": _json(out / "heartbeat.json"),
        "supervisor_exit": _json(out / "supervisor_exit.json"),
        "run_summary": _json(out / "run_summary.json"),
        "reporting": {"cursor": cursor, "unsent_outbox_bytes": backlog, "status": _json(out / "report_status.json"),
                      "quarantined_items": sum(1 for _ in read_jsonl(out / "quarantine.jsonl"))},
        "state": {"companies": len(state), "by_status": dict(statuses)},
        "problem_companies": problems[:100],
        "events": {"total": len(events), "by_level": dict(by_level), "by_code": dict(by_code.most_common(30)),
                   "recent_warnings_and_errors": recent_bad, "last": events[-events_tail:]},
        "log_tails": {"run.log": tail_file(out / "run.log", tail_lines), "supervisor.log": tail_file(out / "supervisor.log", tail_lines)},
        "files": files,
    })


def write_zip(out: Path, destination: Path, report: Optional[Dict[str, Any]] = None) -> Path:
    """The diagnostics document plus the raw local files that matter, in one zip to attach to a report."""
    report = report if report is not None else collect(out)
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("diagnostics.json", json.dumps(report, indent=1, default=str))
        for name in ("events.jsonl", "state.json", "progress.json", "control.json", "report_status.json",
                     "quarantine.jsonl", "results.jsonl", "supervisor_exit.json", "run_summary.json"):
            p = Path(out) / name
            if p.exists() and p.stat().st_size <= 40 * 1024 * 1024:
                z.write(p, name)
        for name in ("run.log", "supervisor.log"):
            lines = tail_file(Path(out) / name, 5000, 3_000_000)
            if lines:
                z.writestr(f"{name}.tail.txt", "\n".join(lines))
    return destination


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Collect diagnostics for a site-evidence run.")
    ap.add_argument("--output-dir", default=str(Path.home() / "SiteEvidenceOutput"))
    ap.add_argument("--zip", default=None, help="also write a zip with the raw local files")
    ap.add_argument("--compact", action="store_true", help="print a single line of JSON")
    args = ap.parse_args(argv)
    report = collect(Path(args.output_dir))
    if args.zip:
        write_zip(Path(args.output_dir), Path(args.zip), report)
        print(f"wrote {args.zip}", file=sys.stderr)
    print(json.dumps(report, indent=None if args.compact else 1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
