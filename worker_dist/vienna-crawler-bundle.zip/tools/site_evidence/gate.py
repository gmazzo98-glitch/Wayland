"""The deterministic check. The model proposes a quote; this decides whether it is real.

Same approach as tools/wayback_timeline/gate.py (itself ported from the Verdantex
evidence harvester): a whitespace/unicode/hyphenation-insensitive substring test. It is
copied rather than imported so that this tool keeps working on a computer where the
other tool is absent or has changed. `fold` is new: accent-stripped lowercase text, used
only for MATCHING keywords ("universita" must find "Università"), never for quoting.
"""
from __future__ import annotations

import re
import unicodedata

_QUOTE_CHARS = {
    "‘": "'", "’": "'", "‚": "'", "′": "'",
    "“": '"', "”": '"', "„": '"', "″": '"',
}
# Non-breaking hyphen, various dash widths, soft hyphen: typography, not a line-wrap artifact.
_DASH_CHARS = "‐‑‒–—―­"
_HYPHEN_BREAK = re.compile(r"([A-Za-z])-\s*\n\s*([a-z])")


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    for src, dst in _QUOTE_CHARS.items():
        text = text.replace(src, dst)
    for ch in _DASH_CHARS:
        text = text.replace(ch, "-")
    text = _HYPHEN_BREAK.sub(r"\1\2", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text.lower()


def quote_verified(quote: str | None, source_text: str) -> bool:
    """True only if `quote` is a verbatim (whitespace/unicode/hyphenation-insensitive)
    substring of `source_text`. A paraphrase, or a quote about the right topic in the
    wrong words, fails on purpose."""
    if not quote or not quote.strip():
        return False
    nq = normalize_text(quote)
    nt = normalize_text(source_text)
    if nq in nt:
        return True
    # Hyphen-tolerant fallback: a line-wrap hyphen is ambiguous about whether the original
    # word had one at all, so a one-character difference is not a paraphrase.
    nq_h, nt_h = nq.replace("-", ""), nt.replace("-", "")
    return bool(nq_h) and nq_h in nt_h


def in_single_line(quote: str, text: str) -> bool:
    """True if the quote sits inside ONE line of the page text. Lines are the page's own block
    boundaries (a heading, a list item, a paragraph). A model that copies "a sentence" across two of
    them has glued unrelated things together (a timeline date to the next entry, a heading to the
    sentence below it), and the glued result can claim more than either part says."""
    nq = normalize_text(quote)
    return bool(nq) and any(nq in normalize_text(line) for line in text.split("\n"))


_BULLET_START = re.compile(r"^[◉•·▪●■►›–—*\-]\s")


def is_list_continuation(quote: str, text: str) -> bool:
    """True if the quote spans several page lines but every line break inside it is a list break:
    the line before ends with ':' or ';', or the next line starts with a bullet marker. That is one
    statement written as an intro plus its items ("we work with: * University A * University B"),
    unlike a timeline year glued onto the next entry or a heading onto the sentence below it."""
    pattern = r"\s+".join(re.escape(tok) for tok in quote.split())
    if not pattern:
        return False
    m = re.search(pattern, text)
    if not m:
        return False
    parts = text[m.start(): m.end()].split("\n")
    if len(parts) < 2:
        return False
    return all(before.rstrip().endswith((":", ";")) or _BULLET_START.match(after.lstrip())
               for before, after in zip(parts, parts[1:]))


_HEADING_YEAR = re.compile(r"^\W*((?:19|20)\d\d)\b")


def heading_year_before(quote: str, text: str, look_back: int = 2):
    """The year of a dated heading directly above the quote's line ("1997/05 - Conquistiamo il
    mondo!" above "export pari al 70%"), or None. Timeline pages put the date on its own line, so a
    sentence can be decades old without containing a single digit of its date."""
    probe = normalize_text(quote)[:60]
    lines = text.split("\n")
    for i, line in enumerate(lines):
        if probe and probe in normalize_text(line):
            for j in range(i - 1, max(-1, i - 1 - look_back), -1):
                m = _HEADING_YEAR.match(lines[j].strip())
                if m and len(lines[j]) <= 90:
                    return int(m.group(1))
            return None
    return None


def lines_inside(quote: str, text: str, min_chars: int = 20) -> list:
    """The page's own lines that lie entirely inside `quote`, in order (used to repair a quote
    that spans lines into the single-line pieces it was glued from)."""
    nq = normalize_text(quote)
    out = []
    for line in text.split("\n"):
        nl = normalize_text(line)
        if len(nl) >= min_chars and nl in nq:
            out.append(line.strip())
    return out


def fold(text: str) -> str:
    """Lowercase, accent-stripped, whitespace-collapsed copy of `text` for keyword matching."""
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    for src, dst in _QUOTE_CHARS.items():
        text = text.replace(src, dst)
    for ch in _DASH_CHARS:
        text = text.replace(ch, "-")
    return re.sub(r"\s+", " ", text).strip().lower()
