"""Keeps the runner alive for days: restarts it after a crash or a hang, never in a hot loop,
and stops for good only when told to (STOP file) or when the work is finished.

    python -m tools.site_evidence.supervisor --input companies.csv --output-dir <folder> [--watch]

What it adds on top of the runner's own resilience:
  - CRASH RESTART with exponential backoff (30 s .. 15 min, reset after a healthy 10-minute run);
  - HANG DETECTION: the runner writes heartbeat.json; if it goes stale for --hang-minutes the
    whole process tree is killed and restarted (a DNS lookup or a stuck socket can freeze a run
    in a way no exception handler sees);
  - NO SLEEP: asks Windows not to put the PC to sleep while it works (SetThreadExecutionState;
    nothing is changed in the power settings and it ends when this process ends);
  - ONE INSTANCE: a pid file with a correct liveness check;
  - --watch keeps the supervisor alive after the work is done, waking every 30 minutes to retry
    companies whose sites were unreachable (those get 3 tries spread over days).

Audit: every start, exit, crash (with the log tail), hang and stop is an event in events.jsonl, and
the way this process ended is written to supervisor_exit.json, so whoever started it (the Vienna
worker, a launcher) can tell "finished" from "died" without guessing.

Exit: 0 finished, 2 stopped by STOP file, 3 fatal configuration (runner exit 3: needs a human).
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from .diagnostics import tail_file
from .events import EventLog, now_iso
from .procutil import keep_awake, kill_tree, pid_alive
from .runner import (DEFAULT_OUTPUT_DIR, EXIT_ALREADY_RUNNING, EXIT_FATAL, EXIT_OK, EXIT_STOPPED, RETRY_AFTER_S, due,
                     load_companies)
from .store import State, atomic_write_json, load_json_with_backup

ROOT = Path(__file__).resolve().parents[2]  # the folder that contains `tools/`
MAX_LOG_BYTES = 10 * 1024 * 1024


def trim_log(path: Path) -> None:
    try:
        if path.exists() and path.stat().st_size > MAX_LOG_BYTES:
            tail = path.read_bytes()[-2 * 1024 * 1024:]
            path.write_bytes(b"[log trimmed]\n" + tail)
    except OSError:
        pass


def heartbeat_age_minutes(out: Path) -> Optional[float]:
    hb = load_json_with_backup(out / "heartbeat.json", None)
    if not isinstance(hb, dict) or "ts" not in hb:
        return None
    try:
        ts = datetime.fromisoformat(hb["ts"])
        return (datetime.now(ts.tzinfo) - ts).total_seconds() / 60.0
    except ValueError:
        return None


def count_due(input_csv: Path, out: Path, limit: int = 0, retry_after_s: float = RETRY_AFTER_S) -> int:
    companies = load_companies(input_csv)
    if limit:
        companies = companies[:limit]
    state = State(out / "state.json")
    now = time.time()
    return sum(1 for c in companies if due(state.get(c["company_id"]), now, retry_after_s))


def count_unfinished(input_csv: Path, out: Path, limit: int = 0) -> int:
    """Companies not yet in a terminal state and with tries left (due now or later)."""
    from .runner import MAX_ATTEMPTS, TERMINAL_STATUSES
    companies = load_companies(input_csv)
    if limit:
        companies = companies[:limit]
    state = State(out / "state.json")
    n = 0
    for c in companies:
        rec = state.get(c["company_id"])
        if rec is None or (rec.get("status") not in TERMINAL_STATUSES and int(rec.get("attempts", 1)) < MAX_ATTEMPTS):
            n += 1
    return n


def main(argv: Optional[List[str]] = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="Keep the site-evidence runner alive.")
    ap.add_argument("--input", required=True)
    ap.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    ap.add_argument("--run-id", default="local")
    ap.add_argument("--watch", action="store_true", help="stay alive after the work is done and retry later")
    ap.add_argument("--hang-minutes", type=float, default=25.0)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--retry-after-hours", type=float, default=RETRY_AFTER_S / 3600.0)
    args, passthrough = ap.parse_known_args(argv)

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    events = EventLog(out / "events.jsonl", "supervisor", args.run_id)
    exit_file = out / "supervisor_exit.json"
    try:
        exit_file.unlink()
    except OSError:
        pass

    def log(msg: str) -> None:
        line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] supervisor: {msg}"
        print(line, flush=True)
        try:
            with (out / "supervisor.log").open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except OSError:
            pass

    outcome: dict = {"code": EXIT_STOPPED, "reason": "interrupted"}
    try:
        code, reason = _supervise(args, passthrough, out, events, log)
        outcome = {"code": code, "reason": reason}
        return code
    except SystemExit as e:  # request_stop(): the console window was closed or the process was told to end
        outcome = {"code": int(e.code or 0), "reason": "window_closed_or_terminated"}
        raise
    except BaseException as e:  # a supervisor bug must be on record, not a silent disappearance
        outcome = {"code": 1, "reason": f"supervisor_crashed: {type(e).__name__}: {e}"[:300]}
        events.error("supervisor_crashed", outcome["reason"])
        raise
    finally:
        try:
            atomic_write_json(exit_file, dict(outcome, at=now_iso(), run_id=args.run_id, pid=os.getpid()))
        except OSError:
            pass


def _supervise(args, passthrough: List[str], out: Path, events: EventLog, log) -> Tuple[int, str]:
    sup_log, run_log = out / "supervisor.log", out / "run.log"
    retry_after_s = args.retry_after_hours * 3600.0
    pid_file = out / "supervisor.pid"
    try:
        other = int(pid_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        other = 0
    if other and other != os.getpid() and pid_alive(other):
        log(f"another supervisor (pid {other}) is already running for this folder; exiting")
        events.warn("another_supervisor", f"Another supervisor (pid {other}) already runs for this folder; this one exits",
                    other_pid=other)
        return EXIT_OK, "another_supervisor_running"
    pid_file.write_text(str(os.getpid()), encoding="utf-8")
    keep_awake()

    stop_file = out / "STOP"

    def request_stop(signum=None, frame=None) -> None:
        # Closing the launcher window must not leave an orphan runner working unsupervised.
        try:
            stop_file.write_text("supervisor was closed", encoding="utf-8")
        except OSError:
            pass
        log("window closed or interrupted; asked the runner to stop after its current step")
        events.info("supervisor_stopped", "The supervisor was closed or terminated; asked the runner to stop",
                    reason="window_closed_or_terminated")
        raise SystemExit(EXIT_STOPPED)

    import signal
    for name in ("SIGBREAK", "SIGTERM"):
        if hasattr(signal, name):
            try:
                signal.signal(getattr(signal, name), request_stop)
            except (ValueError, OSError):
                pass
    trim_log(run_log)
    trim_log(sup_log)

    runner_args = (["--input", args.input, "--output-dir", str(out), "--run-id", args.run_id,
                    "--retry-after-hours", str(args.retry_after_hours)]
                   + (["--limit", str(args.limit)] if args.limit else []) + passthrough)
    backoff = 30.0
    restarts = 0
    log(f"started (pid {os.getpid()}); work folder {out}")
    events.info("supervisor_started", f"Supervisor started for run {args.run_id}", pid=os.getpid(), input=str(args.input),
                watch=args.watch, retry_after_hours=args.retry_after_hours, runner_args=passthrough)
    try:
        while True:
            if stop_file.exists():
                log("STOP file present; not starting a run")
                events.info("supervisor_stopped", "A STOP file is present; not starting a run", reason="stop_file")
                return EXIT_STOPPED, "stop_file"
            if count_due(Path(args.input), out, args.limit, retry_after_s) == 0:
                unfinished = count_unfinished(Path(args.input), out, args.limit)
                if not args.watch or unfinished == 0:
                    log("no work due and nothing left to retry; finished")
                    events.info("supervisor_finished", "No work is due: the run is complete",
                                retry_pending=unfinished)
                    return EXIT_OK, "finished"
                log("only not-yet-due retries remain; sleeping 30 minutes")
                for _ in range(180):
                    if stop_file.exists():
                        break
                    time.sleep(10)
                continue

            started = time.monotonic()
            with run_log.open("ab") as lf:
                proc = subprocess.Popen(
                    [sys.executable, "-u", "-m", "tools.site_evidence.runner"] + runner_args, cwd=str(ROOT),
                    stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                    creationflags=0x08000000 if sys.platform == "win32" else 0)
                log(f"runner started (pid {proc.pid})")
                events.info("runner_started_by_supervisor", f"Runner process {proc.pid} started", pid=proc.pid,
                            restarts=restarts)
                hung = False
                while proc.poll() is None:
                    time.sleep(10)
                    age = heartbeat_age_minutes(out)
                    if age is not None and age > args.hang_minutes and time.monotonic() - started > 120:
                        log(f"runner heartbeat is {age:.0f} minutes old; killing it as hung")
                        events.error("runner_hung", f"The runner stopped reporting for {age:.0f} minutes; killing it",
                                     heartbeat_age_min=round(age, 1), pid=proc.pid,
                                     log_tail=tail_file(run_log, 25))
                        hung = True
                        kill_tree(proc.pid)
                        break
                code = proc.wait()
            ran_for = time.monotonic() - started
            log(f"runner exited with code {code} after {ran_for / 60:.1f} minutes")
            events.info("runner_exited", f"Runner exited with code {code} after {ran_for / 60:.1f} minutes",
                        exit_code=code, minutes=round(ran_for / 60, 1), hung=hung)
            if code == EXIT_STOPPED:
                return EXIT_STOPPED, "stopped"
            if code == EXIT_ALREADY_RUNNING:
                log("another runner already owns this folder; checking again in 60s")
                for _ in range(12):
                    if stop_file.exists():
                        break
                    time.sleep(5)
                continue
            if code == EXIT_FATAL:
                log("fatal configuration problem (see run.log); not restarting")
                events.error("supervisor_fatal", "The runner reported a fatal configuration problem; not restarting",
                             exit_code=code, log_tail=tail_file(run_log, 40))
                return EXIT_FATAL, "fatal_configuration"
            if code == EXIT_OK:
                backoff = 30.0
                continue
            restarts += 1
            backoff = 30.0 if ran_for > 600 else min(backoff * 2, 900.0)
            log(f"crash or hang; restarting in {backoff:.0f}s")
            events.warn("runner_crashed", f"The runner ended unexpectedly (exit code {code}); restarting in {backoff:.0f}s",
                        exit_code=code, ran_minutes=round(ran_for / 60, 1), backoff_s=backoff, restarts=restarts,
                        hung=hung, log_tail=tail_file(run_log, 40))
            end = time.monotonic() + backoff
            while time.monotonic() < end:
                if stop_file.exists():
                    break
                time.sleep(5)
    finally:
        try:
            pid_file.unlink()
        except OSError:
            pass


if __name__ == "__main__":
    sys.exit(main())
