"""HTML -> text and links, standard library only.

html_to_text keeps the lesson from tools/wayback_timeline/text_extract.py: block-level tags
become line breaks, so a short nav label stays visually separate from a real sentence and the
windowing step can tell prose from menu items. `extract_links` and `page_title` are new here:
this tool has to FIND the pages worth reading, not just read a known one.
"""
from __future__ import annotations

import re
import unicodedata
from html import unescape
from html.parser import HTMLParser
from typing import List, Tuple
from urllib.parse import urljoin, urldefrag, urlsplit, urlunsplit

_SCRIPT_STYLE_RE = re.compile(r"<(script|style|noscript|svg)[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL)
_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
_BLOCK_TAG_RE = re.compile(
    r"</?(p|div|br|li|ul|ol|table|tr|td|th|h[1-6]|nav|header|footer|section|article|aside|main|form|blockquote)\b[^>]*>",
    re.IGNORECASE,
)
_ANY_TAG_RE = re.compile(r"<[^>]+>")
_BLANK_LINES_RE = re.compile(r"\n\s*\n+")
_TRAILING_SPACE_RE = re.compile(r"[ \t]+")
_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)


def html_to_text(html: str) -> str:
    text = _COMMENT_RE.sub(" ", html)
    text = _SCRIPT_STYLE_RE.sub(" ", text)
    text = _BLOCK_TAG_RE.sub("\n", text)
    text = _ANY_TAG_RE.sub(" ", text)
    text = unescape(text)
    text = unicodedata.normalize("NFKC", text)
    text = _TRAILING_SPACE_RE.sub(" ", text)
    text = _BLANK_LINES_RE.sub("\n", text)
    lines = [ln.strip() for ln in text.split("\n")]
    return "\n".join(ln for ln in lines if ln)


def page_title(html: str) -> str:
    m = _TITLE_RE.search(html)
    if not m:
        return ""
    return re.sub(r"\s+", " ", unescape(m.group(1))).strip()[:200]


class _LinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: List[Tuple[str, str]] = []
        self._href: str | None = None
        self._text: List[str] = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self._finish()
            self._href = dict(attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag == "a":
            self._finish()

    def _finish(self):
        if self._href is not None:
            self.links.append((self._href, re.sub(r"\s+", " ", "".join(self._text)).strip()))
        self._href = None
        self._text = []

    def close(self):
        self._finish()
        super().close()


_SKIP_SCHEMES = ("mailto:", "tel:", "javascript:", "data:", "whatsapp:", "sms:", "skype:")
_SKIP_EXT = re.compile(
    r"\.(pdf|jpe?g|png|gif|webp|svg|ico|zip|rar|7z|docx?|xlsx?|pptx?|mp[34]|avi|mov|wmv|css|js|json|xml|rss|exe|dmg)$",
    re.IGNORECASE,
)
_KEEP_QUERY = ("p", "page_id", "id", "post", "article")


def is_skippable_url(url: str) -> bool:
    """Images, documents, scripts and the like: never worth fetching as a page, wherever the URL
    came from (a link, or a sitemap, which lists images too)."""
    return bool(_SKIP_EXT.search(urlsplit(url).path))


def normalize_url(url: str) -> str:
    """Drop fragments and tracking/pagination queries; keep ids WordPress-style sites rely on."""
    url, _ = urldefrag(url)
    parts = urlsplit(url)
    query = "&".join(q for q in parts.query.split("&") if q.split("=")[0] in _KEEP_QUERY)
    path = parts.path or "/"
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, query, ""))


def extract_links(html: str, base_url: str) -> List[Tuple[str, str]]:
    """(absolute normalized url, anchor text) for every http(s) link, duplicates removed."""
    parser = _LinkParser()
    try:
        parser.feed(html)
        parser.close()
    except Exception:  # broken markup must not kill a company's run
        pass
    seen, out = set(), []
    for href, text in parser.links:
        href = (href or "").strip()
        if not href or href.startswith("#") or href.lower().startswith(_SKIP_SCHEMES):
            continue
        absolute = normalize_url(urljoin(base_url, href))
        if not absolute.startswith(("http://", "https://")) or _SKIP_EXT.search(urlsplit(absolute).path):
            continue
        if absolute in seen:
            continue
        seen.add(absolute)
        out.append((absolute, text))
    return out
