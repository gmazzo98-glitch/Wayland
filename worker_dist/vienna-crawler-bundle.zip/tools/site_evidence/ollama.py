"""Local model client (Ollama), standard library only, built so that the model being down, slow,
or half-loaded is an ordinary event the job waits out, never a crash.

The Wayback tool called Ollama with no error handling: with Ollama stopped, its first model call
raised URLError and killed the whole run. Here:
  - `tags()` / `loaded()` are cheap health probes (None = unreachable);
  - `start_server()` launches `ollama serve` detached when nothing answers, with the user's
    OLLAMA_* settings read from the Windows registry if the current process missed them (a
    process started before `setx` does not inherit them);
  - `ask_quote()` raises only OllamaUnavailable / OllamaTimeout / OllamaBadResponse, which the
    runner turns into waiting and retrying;
  - the model stays resident between calls (`keep_alive`) because reloading it costs more than
    most calls, and is unloaded explicitly when the job ends so the PC gets its RAM back.

Prompt design is the one real lesson from the Wayback pilot: the model is asked ONLY to copy one
verbatim sentence or return null. It is never asked "is this true?". When it was, it returned a
correct supporting quote and labelled it false. Retrieval is reliable, its own judgment is not.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

DEFAULT_HOST = "http://127.0.0.1:11434"
PREFERRED_MODELS = ("qwen2.5:3b", "qwen2.5-3b-8k")

QUOTE_SCHEMA = {
    "type": "object",
    "properties": {"quote": {"type": ["string", "null"]}},
    "required": ["quote"],
}


class OllamaUnavailable(RuntimeError):
    """The server did not answer (not running, starting up, port refused)."""


class OllamaTimeout(RuntimeError):
    """The server answered the connection but the call took longer than allowed."""


class OllamaBadResponse(RuntimeError):
    """The server answered with something this client cannot use."""


@dataclass
class QuoteCall:
    quote: Optional[str]
    parse_ok: bool
    wall_seconds: float
    prompt_tokens: int = 0
    output_tokens: int = 0
    raw: str = ""


def build_prompt(company_name: str, claim_description: str, passage: str) -> str:
    return (
        f'You are reading text copied from the website of the company "{company_name}".\n'
        f"Task: find ONE sentence in the passage that explicitly says the company {claim_description}.\n"
        "Copy that sentence exactly as written. Do not paraphrase, do not combine sentences, do not guess "
        "and do not use outside knowledge.\n"
        "If the passage does not clearly say this, answer null.\n\n"
        'Passage:\n"""\n' + passage + '\n"""'
    )


@dataclass
class OllamaClient:
    host: str = DEFAULT_HOST
    model: str = ""
    num_ctx: int = 4096
    keep_alive: str = "20m"
    timeout_s: float = 360.0
    opener: Callable = field(default=urllib.request.urlopen)

    # -- probes ---------------------------------------------------------------------------
    def _get_json(self, path: str, timeout: float = 4.0):
        req = urllib.request.Request(f"{self.host}{path}")
        with self.opener(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def tags(self) -> Optional[List[str]]:
        try:
            data = self._get_json("/api/tags")
            return [m.get("name", "") for m in data.get("models", [])]
        except Exception:
            return None

    def loaded(self) -> Optional[List[Dict]]:
        try:
            return list(self._get_json("/api/ps").get("models", []))
        except Exception:
            return None

    def model_loaded(self) -> bool:
        loaded = self.loaded() or []
        return any(m.get("name", "").split(":latest")[0] == self.model.split(":latest")[0] for m in loaded)

    def pick_model(self, available: List[str], preferred: Optional[str] = None) -> Optional[str]:
        names = {n.split(":latest")[0]: n for n in available}
        for want in ([preferred] if preferred else []) + list(PREFERRED_MODELS):
            if want and want.split(":latest")[0] in names:
                return names[want.split(":latest")[0]]
        return None

    # -- the call -------------------------------------------------------------------------
    def ask_quote(self, company_name: str, claim_description: str, passage: str) -> QuoteCall:
        payload = {
            "model": self.model, "stream": False, "keep_alive": self.keep_alive,
            "prompt": build_prompt(company_name, claim_description, passage),
            "format": QUOTE_SCHEMA,
            "options": {"temperature": 0, "num_ctx": self.num_ctx, "num_predict": 220, "seed": 7},
        }
        req = urllib.request.Request(
            f"{self.host}/api/generate", data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        t0 = time.monotonic()
        try:
            with self.opener(req, timeout=self.timeout_s) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:200]
            except Exception:
                pass
            if e.code in (500, 503):  # model loading / out of memory: transient
                raise OllamaUnavailable(f"HTTP {e.code} {body}")
            raise OllamaBadResponse(f"HTTP {e.code} {body}")
        except (TimeoutError, OSError) as e:  # URLError and socket errors are OSErrors
            if "timed out" in str(e).lower() or isinstance(e, TimeoutError):
                raise OllamaTimeout(str(e))
            raise OllamaUnavailable(str(e))
        except ValueError as e:
            raise OllamaBadResponse(f"unreadable response: {e}")
        wall = time.monotonic() - t0
        raw = data.get("response", "") if isinstance(data, dict) else ""
        try:
            parsed = json.loads(raw)
            quote = parsed.get("quote") if isinstance(parsed, dict) else None
            if quote is not None and not isinstance(quote, str):
                quote = None
            parse_ok = isinstance(parsed, dict)
        except ValueError:
            quote, parse_ok = None, False
        return QuoteCall(quote=quote, parse_ok=parse_ok, wall_seconds=round(wall, 2),
                         prompt_tokens=int(data.get("prompt_eval_count", 0) or 0),
                         output_tokens=int(data.get("eval_count", 0) or 0), raw=raw[:400])

    def unload(self) -> None:
        """Free the model's RAM when the job ends. Best effort."""
        try:
            req = urllib.request.Request(
                f"{self.host}/api/generate",
                data=json.dumps({"model": self.model, "keep_alive": 0}).encode("utf-8"),
                headers={"Content-Type": "application/json"}, method="POST")
            with self.opener(req, timeout=15):
                pass
        except Exception:
            pass


# -- starting the server ------------------------------------------------------------------
def find_ollama_exe() -> Optional[str]:
    exe = shutil.which("ollama")
    if exe:
        return exe
    local = os.environ.get("LOCALAPPDATA", "")
    candidate = os.path.join(local, "Programs", "Ollama", "ollama.exe")
    return candidate if os.path.exists(candidate) else None


def _registry_user_env(name: str) -> Optional[str]:
    if sys.platform != "win32":
        return None
    try:
        import winreg  # type: ignore
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            value, _ = winreg.QueryValueEx(key, name)
            return str(value)
    except OSError:
        return None


def server_env() -> Dict[str, str]:
    env = dict(os.environ)
    for name in ("OLLAMA_MODELS", "OLLAMA_NUM_PARALLEL", "OLLAMA_MAX_LOADED_MODELS"):
        if not env.get(name):
            value = _registry_user_env(name)
            if value:
                env[name] = value
    env.setdefault("OLLAMA_NUM_PARALLEL", "1")
    env.setdefault("OLLAMA_MAX_LOADED_MODELS", "1")
    return env


def start_server(client: OllamaClient, wait_s: float = 90.0, log: Callable[[str], None] = print) -> bool:
    """Start `ollama serve` detached if nothing answers; True once it does. Never raises."""
    if client.tags() is not None:
        return True
    exe = find_ollama_exe()
    if not exe:
        log("ollama executable not found; cannot start the model server")
        return False
    log(f"model server not answering; starting {exe} serve")
    flags = 0
    if sys.platform == "win32":
        flags = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED_PROCESS | NEW_PROCESS_GROUP | NO_WINDOW
    try:
        subprocess.Popen([exe, "serve"], env=server_env(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=flags, close_fds=True)
    except OSError as e:
        log(f"could not start the model server: {e}")
        return False
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        if client.tags() is not None:
            log("model server is up")
            return True
        time.sleep(2.0)
    log("model server did not come up in time")
    return False
