"""Reads each company's OWN website for partnership, research, innovation-programme and export
evidence, one verbatim quote at a time, using a local model that costs nothing per token.

    python -m tools.site_evidence.runner --input companies.csv --output-dir <folder>

Meant to run for days, so the rules of the house are about surviving, not speed:
  - RESUMABLE: progress is saved after every company; every model answer is cached by content, so
    even a crash mid-company repeats no call.
  - NEVER DIES ON A DEPENDENCY: model server down -> start it, then wait and retry; RAM low ->
    wait; website unreachable -> record why and retry later (3 tries over days); one company's bug
    is recorded against that company and the run moves on.
  - BOUNDED AND STOPPABLE: a STOP file in the output folder is checked between every unit of
    work; --max-minutes is a hard budget; the supervisor (supervisor.py) restarts a crashed or
    hung run.
  - POLITE: robots.txt obeyed, >= 2 s between requests to one host, honest user agent, no logins.
  - HONEST: a result is a verbatim quote from a page, found by the model AND passed by the claim's
    own rules. "Nothing found" is recorded as 'checked', never as a confirmed absence.

Exit codes: 0 all due work finished; 1 unexpected error (supervisor restarts); 2 stopped by STOP
file / time budget / Ctrl-C (supervisor does not restart); 3 fatal configuration (no model
installed, bad input) that retrying cannot fix; 4 another runner already owns this folder
(supervisor waits instead of starting a second).
"""
from __future__ import annotations

import argparse
import atexit
import csv
import os
import re
import socket
import sys
import time
import traceback
from collections import Counter, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlsplit, urlunsplit

from .buildinfo import environment, tool_build
from .claims import CLAIM_ORDER, CLAIMS, RULES_VERSION, Claim
from .discover import parse_sitemap, rank_candidates
from .events import EventLog
from .fetcher import Fetcher, FetchResult, host_of, same_site
from .gate import (fold, heading_year_before, in_single_line, is_list_continuation, lines_inside,
                   quote_verified)
from .ollama import (OllamaBadResponse, OllamaClient, OllamaTimeout, OllamaUnavailable, find_ollama_exe,
                     start_server)
from .procutil import pid_alive
from .ram_guard import JobGuard, StoppedError, TimeBudgetError, free_ram_gb
from .signals import derive_signals
from .store import LlmCache, State, append_jsonl, atomic_write_json, read_jsonl
from .text_extract import extract_links, html_to_text, normalize_url, page_title
from .wayback_dating import WaybackClient, WaybackError, first_seen
from .windows import find_windows, split_sentences, strip_boilerplate

EXIT_OK, EXIT_ERROR, EXIT_STOPPED, EXIT_FATAL, EXIT_ALREADY_RUNNING = 0, 1, 2, 3, 4

DEFAULT_OUTPUT_DIR = Path.home() / "SiteEvidenceOutput"
TERMINAL_STATUSES = {"done", "no_website", "robots_blocked", "blocked", "bad_homepage"}
MAX_ATTEMPTS = 3
RETRY_AFTER_S = 6 * 3600
SKIPPED = object()  # a window the model could not answer after retries; not cached, not a "no"

_LEGAL_WORDS = {"spa", "srl", "sas", "snc", "sapa", "scarl", "srls", "societa", "a", "responsabilita", "limitata",
                "per", "azioni", "gmbh", "ag", "ltd", "inc", "co", "cooperativa", "consortile", "unipersonale",
                "semplificata", "in", "di", "e", "the", "and", "sa", "sl"}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def name_tokens(name: str) -> Tuple[str, ...]:
    words = re.findall(r"[A-Za-zÀ-ÿ0-9]+", name or "")
    return tuple(w for w in words if fold(w) not in _LEGAL_WORDS and len(w) > 2)


def normalize_homepage(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    if "://" not in url:
        url = "https://" + url
    parts = urlsplit(url)
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path or "/", "", ""))


def host_variants(url: str) -> List[str]:
    """The URL as given, then the same with `www.` toggled (small sites often only answer one)."""
    parts = urlsplit(url)
    host = parts.netloc
    alt = host[4:] if host.startswith("www.") else "www." + host
    out = [url]
    if alt.count(".") >= 1:
        out.append(urlunsplit((parts.scheme, alt, parts.path or "/", "", "")))
    return out


def stale_rules(record: Optional[Dict[str, Any]]) -> bool:
    """A finished company that was judged under an older, looser rules version. The model answers are
    cached, so judging it again costs fetch time only, and it keeps old rules from silently outliving
    a tightening (the importer and the database refuse findings stamped with an old version anyway)."""
    return bool(record) and record.get("status") == "done" and int(record.get("rules_version", 1)) < RULES_VERSION


def due(record: Optional[Dict[str, Any]], now_ts: float, retry_after_s: float = RETRY_AFTER_S) -> bool:
    if record is None:
        return True
    if stale_rules(record):
        return True
    if record.get("status") in TERMINAL_STATUSES:
        return False
    if int(record.get("attempts", 1)) >= MAX_ATTEMPTS:
        return False
    if record.get("status") == "partial":
        return True
    return now_ts - float(record.get("finished_ts", 0)) >= retry_after_s


def load_companies(path: Path) -> List[Dict[str, str]]:
    with Path(path).open(encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.DictReader(fh))
    out = []
    for r in rows:
        cid = (r.get("company_id") or "").strip()
        if cid:
            out.append({"company_id": cid, "homepage_url": (r.get("homepage_url") or "").strip(),
                        "name": (r.get("name") or r.get("legal_name") or cid).strip()})
    return out


# ---------------------------------------------------------------------------------------------
@dataclass
class Page:
    url: str
    html: str
    text: str
    title: str
    via: str = "live"          # live | wayback
    snapshot_ts: Optional[str] = None


@dataclass
class Site:
    base_url: str = ""
    pages: Dict[str, Page] = field(default_factory=dict)
    failed: List[Tuple[str, str]] = field(default_factory=list)
    status: str = "ok"          # ok | no_website | robots_blocked | blocked | bad_homepage | site_unreachable
    detail: str = ""

    @property
    def via(self) -> str:
        kinds = {p.via for p in self.pages.values()}
        return "wayback" if kinds == {"wayback"} else ("mixed" if len(kinds) > 1 else "live")


@dataclass
class Runtime:
    out: Path
    fetcher: Fetcher
    wayback: Optional[WaybackClient]
    llm: Optional[OllamaClient]
    guard: JobGuard
    cache: LlmCache
    state: State
    log: Callable[[str], None]
    beat: Callable[..., None]
    year_now: int
    max_pages: int = 12
    max_company_seconds: float = 2700.0
    date_hits: bool = True
    wayback_rescue: bool = True
    sizing_only: bool = False
    sleep: Callable[[float], None] = time.sleep
    events: Optional[EventLog] = None
    run_id: str = "local"
    model_down_since: Optional[float] = None   # monotonic time the model server first stopped answering
    ram_wait_since: Optional[float] = None     # monotonic time the RAM wait began
    company_hits: List[Dict[str, Any]] = field(default_factory=list)  # full hit dicts of the company in progress
    stats: Dict[str, Any] = field(default_factory=lambda: {
        "llm_calls": 0, "cache_hits": 0, "llm_seconds": 0.0, "prompt_tokens": 0, "output_tokens": 0,
        "parse_failures": 0, "skipped_windows": 0, "rejected_not_verbatim": 0, "rejected_rules": 0, "hits": {}})

    @property
    def results_path(self) -> Path:
        return self.out / "results.jsonl"

    def sleep_checked(self, seconds: float) -> None:
        """Sleep in short slices so a STOP file or the time budget is honoured promptly."""
        remaining = float(seconds)
        while remaining > 0:
            self.guard.check_stop_and_time()
            step = min(5.0, remaining)
            self.sleep(step)
            remaining -= step


# ---- reading a site --------------------------------------------------------------------------
def _add_page(site: Site, url: str, html: str, via: str = "live", ts: Optional[str] = None) -> Page:
    page = Page(url=url, html=html, text=html_to_text(html), title=page_title(html), via=via, snapshot_ts=ts)
    site.pages[url] = page
    return page


def _sitemap_urls(rt: Runtime, base_url: str, limit: int = 600) -> List[str]:
    parts = urlsplit(base_url)
    roots = rt.fetcher.sitemaps(base_url) or [f"{parts.scheme}://{parts.netloc}/sitemap.xml"]
    urls: List[str] = []
    queue, seen = list(roots[:2]), set()
    while queue and len(urls) < limit and len(seen) < 4:
        sm = queue.pop(0)
        if sm in seen:
            continue
        seen.add(sm)
        res = rt.fetcher.get_text(sm)
        rt.guard.check_stop_and_time()
        if not res.ok:
            continue
        pages, children = parse_sitemap(res.html, limit=limit)
        urls.extend(pages)
        queue.extend(children[:2])
    return urls[:limit]


def read_site(homepage: str, rt: Runtime) -> Site:
    site = Site()
    started = time.monotonic()
    first: Optional[FetchResult] = None
    primary: Optional[FetchResult] = None  # the URL as given: its failure stays the authoritative one
    for i, variant in enumerate(host_variants(homepage)):
        rt.guard.check_stop_and_time()
        res = rt.fetcher.get(variant)
        if i == 0:
            primary = res
        if res.ok:
            first = res
            break
        if res.kind not in ("dns", "conn", "tls", "timeout", "notfound", "server"):
            break  # a settled answer (robots, blocked, not html): the other spelling will not change it
    if first is None:
        assert primary is not None
        return _rescue_or_fail(site, homepage, primary, rt)

    base = first.final_url or homepage
    site.base_url = base
    _add_page(site, normalize_url(base), first.html)
    pool: List[Tuple[str, str]] = list(extract_links(first.html, base))
    for u in _sitemap_urls(rt, base):
        pool.append((normalize_url(u), ""))
    failed: set = set()
    while len(site.pages) < rt.max_pages and time.monotonic() - started < rt.max_company_seconds / 3:
        rt.guard.check_stop_and_time()
        ranked = rank_candidates(base, pool, exclude=list(site.pages) + list(failed))
        if not ranked:
            break
        _, url = ranked[0]
        res = rt.fetcher.get(url)
        if res.ok:
            page_url = normalize_url(res.final_url or url)
            if page_url in site.pages:
                failed.add(url)
                continue
            _add_page(site, page_url, res.html)
            failed.add(url)
            pool.extend(extract_links(res.html, page_url))
        else:
            failed.add(url)
            site.failed.append((url, res.kind))
    return site


def _rescue_or_fail(site: Site, homepage: str, first: FetchResult, rt: Runtime) -> Site:
    """The homepage could not be read live. Settled answers end here; transient ones may be
    rescued from the archive (never robots- or bot-blocked sites)."""
    if first.kind == "robots":
        site.status, site.detail = "robots_blocked", first.detail
        return site
    if first.kind == "blocked":
        site.status, site.detail = "blocked", first.detail
        return site
    if first.kind == "not_html":
        site.status, site.detail = "bad_homepage", first.detail
        return site
    site.failed.append((homepage, first.kind))
    site.detail = f"{first.kind}: {first.detail}"
    if first.kind == "notfound":
        site.status = "bad_homepage"
        return site
    site.status = "site_unreachable"
    if not (rt.wayback and rt.wayback_rescue):
        return site
    try:
        cap = rt.wayback.latest(homepage)
        if cap is None:
            site.detail += "; no archived copy"
            return site
        html = rt.wayback.fetch(cap)
    except (WaybackError, ValueError) as e:
        site.detail += f"; archive unavailable ({str(e)[:80]})"
        return site
    site.status, site.base_url = "ok", homepage
    _add_page(site, normalize_url(homepage), html, via="wayback", ts=cap.timestamp)
    pool = extract_links(html, homepage)
    failed: set = set()
    while len(site.pages) < 6:
        rt.guard.check_stop_and_time()
        ranked = rank_candidates(homepage, pool, exclude=list(site.pages) + list(failed))
        if not ranked:
            break
        _, url = ranked[0]
        failed.add(url)
        try:
            sub = rt.wayback.latest(url)
            if sub is None:
                continue
            _add_page(site, normalize_url(url), rt.wayback.fetch(sub), via="wayback", ts=sub.timestamp)
        except (WaybackError, ValueError):
            site.failed.append((url, "archive"))
    return site


# ---- asking the model ------------------------------------------------------------------------
def _ram_wait_notice(rt: Runtime, msg: str) -> None:
    """RAM waits are normal on this PC; what matters in an audit is how long the job was starved, so a
    wait is reported once when it starts (and at most every 30 minutes while it lasts) and once with its
    duration when it ends, never once per minute for a week."""
    rt.log(msg)
    rt.beat(waiting_for="ram")
    if rt.events is None:
        return
    now = time.monotonic()
    if msg.startswith("RAM freed"):
        if rt.ram_wait_since is not None:
            waited = now - rt.ram_wait_since
            rt.ram_wait_since = None
            if waited >= 120:
                rt.events.info("ram_wait_end", f"Enough RAM again after {waited / 60:.1f} minutes", seconds=round(waited),
                               free_gb=round(free_ram_gb(), 2))
        return
    if rt.ram_wait_since is None:
        rt.ram_wait_since = now
    rt.events.throttled("ram_wait", 1800, now, "warn", "ram_waiting", msg, free_gb=round(free_ram_gb(), 2),
                        waiting_s=round(now - rt.ram_wait_since))


def ask_model(rt: Runtime, company: Dict[str, str], claim: Claim, passage: str):
    """Quote (str), None (the model found nothing), or SKIPPED. Waits out outages; honours STOP."""
    assert rt.llm is not None
    key = rt.cache.key(rt.llm.model, claim.id, passage)
    if rt.cache.has(key):
        rt.stats["cache_hits"] += 1
        return rt.cache.get(key)
    backoff, trouble = 20.0, 0
    while True:
        rt.guard.check(model_loaded=rt.llm.model_loaded(), on_wait=lambda m: _ram_wait_notice(rt, m))
        rt.beat(step=f"model:{claim.id}", waiting_for=None)
        try:
            call = rt.llm.ask_quote(company["name"], claim.description, passage)
        except OllamaUnavailable as e:
            now = time.monotonic()
            if rt.model_down_since is None:
                rt.model_down_since = now
            rt.log(f"model server unavailable ({str(e)[:100]}); retrying in {backoff:.0f}s")
            if rt.events:
                rt.events.throttled("model_down", 600, now, "warn", "model_unavailable",
                                    f"The model server is not answering ({str(e)[:160]}); retrying with backoff",
                                    retry_in_s=backoff, down_for_s=round(now - rt.model_down_since))
            rt.beat(waiting_for="model")
            start_server(rt.llm, wait_s=45, log=rt.log)
            rt.sleep_checked(backoff)
            backoff = min(backoff * 2, 600.0)
            continue
        except (OllamaTimeout, OllamaBadResponse) as e:
            trouble += 1
            rt.log(f"model call problem {trouble}/2: {type(e).__name__} {str(e)[:100]}")
            if rt.events:
                rt.events.throttled("model_call_failed", 300, time.monotonic(), "warn", "model_call_failed",
                                    f"{type(e).__name__}: {str(e)[:200]}", attempt=trouble, claim=claim.id,
                                    company=company["company_id"])
            if trouble >= 2:
                rt.stats["skipped_windows"] += 1
                return SKIPPED
            rt.sleep_checked(10.0)
            continue
        if rt.model_down_since is not None:
            down = time.monotonic() - rt.model_down_since
            rt.model_down_since = None
            if rt.events:
                rt.events.info("model_recovered", f"The model server answers again after {down / 60:.1f} minutes",
                               downtime_s=round(down))
        rt.stats["llm_calls"] += 1
        rt.stats["llm_seconds"] += call.wall_seconds
        rt.stats["prompt_tokens"] += call.prompt_tokens
        rt.stats["output_tokens"] += call.output_tokens
        if not call.parse_ok:
            rt.stats["parse_failures"] += 1
        rt.cache.put(key, call.quote)
        return call.quote


# ---- one company -----------------------------------------------------------------------------
def candidate_quotes(proposed: str, page_text: str) -> List[str]:
    """The quote(s) a verified model answer may be judged as. A quote inside one page line is judged
    as is. One that spans several lines was glued together by the model (a timeline year onto the
    next entry, a heading onto the sentence below), so it is replaced by the page's own whole lines
    that lie inside it, each judged on its own. Over-long lines are cut into sentences."""
    if in_single_line(proposed, page_text):
        pieces = [proposed]
    elif is_list_continuation(proposed, page_text):
        pieces = [proposed]          # an intro line ending in ':' and its bullet items are ONE statement
    else:
        pieces = lines_inside(proposed, page_text)
    out: List[str] = []
    for piece in pieces:
        if len(piece) <= 600:
            out.append(piece)
        elif "\n" in piece:          # a long list: keep the intro and as many whole items as fit
            kept: List[str] = []
            for ln in piece.split("\n"):
                if len("\n".join(kept + [ln])) > 600:
                    break
                kept.append(ln)
            if kept:
                out.append("\n".join(kept))
        else:
            out.extend(s for s in split_sentences(piece) if 25 <= len(s) <= 600)
    return out


def _reject(rt: Runtime, record: Dict[str, Any], reason: str, claim_id: str, quote: str) -> None:
    """Count a rejected model answer and keep a few of them, so tuning the rules on a long run is
    done from what the model actually said rather than from guesses."""
    record["rejected"][reason] = record["rejected"].get(reason, 0) + 1
    rt.stats[f"rejected_{reason}"] = rt.stats.get(f"rejected_{reason}", 0) + 1
    samples = record.setdefault("rejected_samples", [])
    if len(samples) < 8:
        samples.append({"claim": claim_id, "reason": reason, "quote": quote[:240]})


def process_company(company: Dict[str, str], rt: Runtime, attempts: int) -> Dict[str, Any]:
    cid, name = company["company_id"], company["name"]
    t0 = time.monotonic()
    rt.company_hits = []
    record: Dict[str, Any] = {
        "company_id": cid, "name": name, "homepage_url": company["homepage_url"], "attempts": attempts,
        "started_at": now_iso(), "windows": {}, "hits": [],
        "rejected": {"not_verbatim": 0, "rules": 0, "multiline": 0},
    }
    homepage = normalize_homepage(company["homepage_url"])
    if not homepage:
        record.update(status="no_website")
        return record

    rt.beat(company_id=cid, name=name, step="reading site")
    site = read_site(homepage, rt)
    record.update(
        via=site.via if site.pages else None, pages_read=len(site.pages),
        pages=[{"url": u, "via": p.via, "snapshot_ts": p.snapshot_ts, "chars": len(p.text)} for u, p in site.pages.items()],
        pages_failed=[{"url": u, "kind": k} for u, k in site.failed[:20]], site_detail=site.detail[:200],
    )
    if site.status != "ok" or not site.pages:
        record.update(status=site.status if site.status != "ok" else "site_unreachable")
        return record

    texts = {u: p.text for u, p in site.pages.items()}
    lines = strip_boilerplate(texts)
    ctx = {"own_name_tokens": name_tokens(name), "year_now": rt.year_now}
    over_budget = False

    for claim_id in CLAIM_ORDER:
        claim = CLAIMS[claim_id]
        windows = find_windows(lines, claim)
        record["windows"][claim_id] = len(windows)
        if rt.sizing_only and claim.mode == "llm":
            continue
        for window in windows:
            rt.guard.check_stop_and_time()
            if time.monotonic() - t0 > rt.max_company_seconds:
                over_budget = True
                break
            page = site.pages[window.url]
            quote: Optional[str] = None
            extra: Optional[Dict[str, Any]] = None
            if claim.mode == "rules":
                for sentence in split_sentences(window.text):
                    if in_single_line(sentence, page.text):  # windows join lines; a quote must not
                        got = claim.validate(sentence, dict(ctx, context_year=heading_year_before(sentence, page.text)))
                        if got is not None:
                            quote, extra = sentence, got
                            break
            else:
                proposed = ask_model(rt, company, claim, window.text)
                if proposed is SKIPPED or proposed is None:
                    continue
                if not quote_verified(proposed, page.text):
                    _reject(rt, record, "not_verbatim", claim.id, proposed)
                    continue
                candidates = candidate_quotes(proposed, page.text)
                if not candidates:
                    _reject(rt, record, "multiline", claim.id, proposed)
                    continue
                for candidate in candidates:
                    got = claim.validate(candidate, dict(ctx, context_year=heading_year_before(candidate, page.text)))
                    if got is not None:
                        quote, extra = candidate, got
                        break
                if quote is None:
                    _reject(rt, record, "rules", claim.id, proposed)
                    continue
            if quote is None:
                continue
            hit = {
                "company_id": cid, "name": name, "claim": claim.id, "indicator": claim.indicator,
                "quote": quote, "page_url": window.url, "page_title": page.title, "via": page.via,
                "snapshot_ts": page.snapshot_ts, "found_at": now_iso(), "mode": claim.mode,
                "rules_version": RULES_VERSION,
                "model": rt.llm.model if (rt.llm and claim.mode == "llm") else None,
                "num_ctx": rt.llm.num_ctx if (rt.llm and claim.mode == "llm") else None,
                **(extra or {}),
            }
            if rt.date_hits and rt.wayback:
                rt.beat(step=f"dating:{claim.id}")
                hit["first_seen"] = first_seen(rt.wayback, window.url, quote)
            append_jsonl(rt.results_path, hit)
            rt.company_hits.append(hit)
            record["hits"].append(claim.id)
            rt.stats["hits"][claim.id] = rt.stats["hits"].get(claim.id, 0) + 1
            rt.log(f"  HIT {claim.id}: {quote[:110]}")
            if claim.stop_after_first:
                break
        if over_budget:
            break

    record["status"] = "partial" if over_budget else "done"
    record["seconds"] = round(time.monotonic() - t0, 1)
    return record


# ---- the run ---------------------------------------------------------------------------------
class Heartbeat:
    def __init__(self, path: Path, interval: float = 3.0):
        self.path, self.interval = Path(path), interval
        self._last = 0.0
        self.data: Dict[str, Any] = {"pid": os.getpid(), "started_at": now_iso()}

    def __call__(self, force: bool = False, **fields: Any) -> None:
        self.data.update(fields)
        if not force and time.monotonic() - self._last < self.interval:
            return
        self._last = time.monotonic()
        self.data["ts"] = now_iso()
        try:
            atomic_write_json(self.path, self.data)
        except OSError:
            pass  # a locked heartbeat file must never stop the job


class Progress:
    """progress.json: what the app and the status command show (counts, speed, time left). Small on
    purpose and rewritten after every company; the audit detail lives in events.jsonl."""

    def __init__(self, path: Path, run_id: str, total: int, pending: int, state_data: Dict[str, Dict[str, Any]],
                 model: str):
        self.path = Path(path)
        self.run_id, self.total, self.pending, self.model = run_id, total, pending, model
        self.done_before = total - pending
        self.processed = 0
        self.by_status: Counter = Counter(rec.get("status") for rec in state_data.values())
        self.hits_by_claim: Counter = Counter()
        for rec in state_data.values():
            for claim in rec.get("hits") or []:
                self.hits_by_claim[claim] += 1
        self.started_at = now_iso()
        self.seconds: deque = deque(maxlen=40)
        self.last_company: Optional[Dict[str, Any]] = None

    def company_done(self, prev: Optional[Dict[str, Any]], record: Dict[str, Any], wall_seconds: float) -> None:
        self.processed += 1
        if prev:  # a company judged again (retry, or older rules) replaces its previous outcome
            self.by_status[prev.get("status")] -= 1
            for claim in prev.get("hits") or []:
                self.hits_by_claim[claim] -= 1
        self.by_status[record.get("status")] += 1
        for claim in record.get("hits") or []:
            self.hits_by_claim[claim] += 1
        self.seconds.append(wall_seconds)
        self.last_company = {"company_id": record.get("company_id"), "name": record.get("name"),
                             "status": record.get("status"), "hits": record.get("hits"), "at": record.get("finished_at")}

    def snapshot(self, state: str = "running", **extra: Any) -> Dict[str, Any]:
        avg = (sum(self.seconds) / len(self.seconds)) if self.seconds else None
        remaining = max(0, self.pending - self.processed)
        data = {
            "run_id": self.run_id, "state": state, "started_at": self.started_at, "updated_at": now_iso(),
            "pid": os.getpid(), "total": self.total, "done": self.done_before + self.processed,
            "remaining": remaining, "processed_this_session": self.processed,
            "hits_total": sum(v for v in self.hits_by_claim.values() if v > 0),
            "hits_by_claim": {k: v for k, v in self.hits_by_claim.items() if v > 0},
            "by_status": {str(k): v for k, v in self.by_status.items() if v > 0},
            "avg_seconds_per_company": round(avg, 1) if avg else None,
            "eta_seconds": round(remaining * avg) if avg and remaining else (0 if not remaining else None),
            "rules_version": RULES_VERSION, "tool_build": tool_build(), "model": self.model,
            "last_company": self.last_company,
        }
        data.update(extra)
        return data

    def write(self, state: str = "running", **extra: Any) -> None:
        try:
            atomic_write_json(self.path, self.snapshot(state, **extra))
        except OSError:
            pass  # progress is informational; it must never stop the job


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--input", required=True, help="CSV: company_id, homepage_url, name")
    ap.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    ap.add_argument("--run-id", default="local", help="identifies this run in the audit trail (set by the Vienna app)")
    ap.add_argument("--limit", type=int, default=0, help="only the first N companies of the input (pilot)")
    ap.add_argument("--max-minutes", type=float, default=0.0, help="hard time budget, 0 = none")
    ap.add_argument("--model", default=None, help="Ollama model (default: qwen2.5:3b, else qwen2.5-3b-8k)")
    ap.add_argument("--host", default="http://127.0.0.1:11434")
    ap.add_argument("--num-ctx", type=int, default=4096)
    ap.add_argument("--max-pages", type=int, default=12)
    ap.add_argument("--min-free-gb-to-load", type=float, default=2.0)
    ap.add_argument("--min-free-gb-loaded", type=float, default=0.5)
    ap.add_argument("--retry-after-hours", type=float, default=RETRY_AFTER_S / 3600.0,
                    help="how long an unreachable site waits before it is tried again (0 = retry at once)")
    ap.add_argument("--no-wayback-rescue", action="store_true")
    ap.add_argument("--no-date-hits", action="store_true")
    ap.add_argument("--no-llm", action="store_true", help="sizing mode: fetch pages, count passages, no model, nothing saved as done")
    return ap


def _final_state(code: int, pending_left: int) -> str:
    if code == EXIT_OK:
        return "finished"
    if code == EXIT_STOPPED:
        return "stopped"
    return "failed"


def _traceback_tail(limit: int = 14) -> List[str]:
    return traceback.format_exc().strip().splitlines()[-limit:]


def run(args: argparse.Namespace, *, fetcher: Optional[Fetcher] = None, llm: Optional[OllamaClient] = None,
        wayback: Optional[WaybackClient] = None, sleep: Callable[[float], None] = time.sleep) -> int:
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    run_id = getattr(args, "run_id", None) or "local"
    retry_after_s = float(getattr(args, "retry_after_hours", RETRY_AFTER_S / 3600.0)) * 3600.0
    events = EventLog(out / "events.jsonl", "runner", run_id)

    def log(msg: str) -> None:  # the supervisor redirects stdout into run.log
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)

    pid_file = out / "runner.pid"
    # Two runners on one folder would interleave writes to state.json and double every model call.
    # A runner can outlive its supervisor (its window was closed), so the next start must notice.
    try:
        other = int(pid_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        other = 0
    if other and other != os.getpid() and pid_alive(other):
        log(f"another runner (pid {other}) is already working on this folder; not starting a second one")
        events.warn("runner_already_running", f"Another runner (pid {other}) owns this folder; not starting a second one",
                    other_pid=other)
        return EXIT_ALREADY_RUNNING
    pid_file.write_text(str(os.getpid()), encoding="utf-8")
    atexit.register(lambda: pid_file.unlink(missing_ok=True))
    socket.setdefaulttimeout(45)
    _lower_priority()

    try:
        companies = load_companies(Path(args.input))
    except (OSError, csv.Error) as e:
        log(f"cannot read input: {e}")
        events.error("input_unreadable", f"Cannot read the company list {args.input}: {e}", input=str(args.input))
        return EXIT_FATAL
    if args.limit:
        companies = companies[: args.limit]
    state = State(out / "state.json")
    now_ts = time.time()
    pending = [c for c in companies if due(state.get(c["company_id"]), now_ts, retry_after_s)]
    stale = sum(1 for c in companies if stale_rules(state.get(c["company_id"])))

    beat = Heartbeat(out / "heartbeat.json")
    beat(force=True, run_id=run_id, total=len(pending), done=0, hits_total=0, step="starting")
    log(f"{len(companies)} companies in input, {len(pending)} due. Output: {out}")
    log(f"Stop anytime by creating a file named STOP in {out}.")

    guard = JobGuard(output_dir=out, max_minutes=args.max_minutes,
                     min_free_gb_to_load=args.min_free_gb_to_load, min_free_gb_loaded=args.min_free_gb_loaded)
    client = None
    if not args.no_llm:
        client = llm or OllamaClient(host=args.host, model=args.model or "", num_ctx=args.num_ctx)
        if not client.tags():
            events.warn("model_server_starting", "The model server is not answering; starting it")
            start_server(client, wait_s=90, log=log)
        available = client.tags()
        if available is None:
            log("the model server is not reachable and could not be started; exiting so the supervisor retries")
            events.error("model_server_unreachable", "The model server could not be reached or started; the supervisor will retry",
                         executable_found=bool(find_ollama_exe()))
            return EXIT_ERROR
        chosen = client.pick_model(available, args.model)
        if not chosen:
            log(f"no suitable model installed (have: {', '.join(available) or 'none'}). Install one with "
                f"`ollama pull qwen2.5:3b`. Not retrying: this needs a human.")
            events.error("model_missing", "No suitable model is installed. Run `ollama pull qwen2.5:3b`; this needs a human",
                         installed=available, wanted=args.model or "qwen2.5:3b")
            return EXIT_FATAL
        client.model = chosen
        log(f"model: {client.model} (num_ctx {client.num_ctx})")

    uses_archive = not (args.no_wayback_rescue and args.no_date_hits)
    rt = Runtime(
        out=out, fetcher=fetcher or Fetcher(), wayback=(wayback or WaybackClient()) if uses_archive else None,
        llm=client, guard=guard, cache=LlmCache(out / "llm_cache.jsonl"), state=state, log=log, beat=beat,
        year_now=datetime.now(timezone.utc).year, max_pages=args.max_pages, date_hits=not args.no_date_hits,
        wayback_rescue=not args.no_wayback_rescue, sizing_only=args.no_llm, sleep=sleep,
        events=events, run_id=run_id,
    )
    log(f"{len(rt.cache)} cached model answers loaded")
    progress = Progress(out / "progress.json", run_id, len(companies), len(pending), state.data,
                        client.model if client else "")
    progress.write("running")
    events.info("runner_started", f"Runner started: {len(pending)} of {len(companies)} companies due",
                pid=os.getpid(), total=len(companies), pending=len(pending), stale_rules=stale,
                model=client.model if client else None, num_ctx=client.num_ctx if client else None,
                free_ram_gb=round(free_ram_gb(), 2), min_free_gb_to_load=args.min_free_gb_to_load,
                min_free_gb_loaded=args.min_free_gb_loaded, retry_after_hours=round(retry_after_s / 3600, 2),
                **environment())

    code = EXIT_OK
    done = 0
    try:
        for company in pending:
            guard.check_stop_and_time()
            cid = company["company_id"]
            prev = state.get(cid)
            attempts = 1 if stale_rules(prev) else int((prev or {}).get("attempts", 0)) + 1
            log(f"[{done + 1}/{len(pending)}] {company['name']}  {company['homepage_url']}")
            beat(force=True, company_id=cid, name=company["name"], step="starting company", done=done)
            t_company = time.monotonic()
            try:
                record = process_company(company, rt, attempts)
            except (StoppedError, TimeBudgetError):
                raise
            except Exception as e:  # one company's bug must not end a multi-day run
                log(f"  company failed with {type(e).__name__}: {e}")
                log("  " + traceback.format_exc().strip().splitlines()[-2][:200])
                events.error("company_error", f"{company['name']}: {type(e).__name__}: {e}"[:400], company_id=cid,
                             name=company["name"], homepage_url=company["homepage_url"], attempt=attempts,
                             step=beat.data.get("step"), traceback=_traceback_tail())
                record = {"company_id": cid, "name": company["name"], "homepage_url": company["homepage_url"],
                          "status": "partial", "attempts": attempts, "error": f"{type(e).__name__}: {e}"[:300]}
            record["finished_at"], record["finished_ts"] = now_iso(), time.time()
            record["rules_version"] = RULES_VERSION
            hits_detail = list(rt.company_hits)
            if rt.sizing_only:
                append_jsonl(out / "sizing.jsonl", record)
            else:
                # Outbox first, state second: a crash between the two re-processes the company (the model
                # answers are cached, the database ignores a repeat) instead of losing its report.
                append_jsonl(out / "outbox.jsonl", {
                    "v": 1, "run_id": run_id, "company_id": cid, "name": company["name"],
                    "finished_at": record["finished_at"], "rules_version": RULES_VERSION, "tool_build": tool_build(),
                    "record": record, "hits": hits_detail, "signals": derive_signals(hits_detail, rt.year_now),
                })
                state.put(cid, record)
            _record_company_events(events, record)
            done += 1
            progress.company_done(prev, record, time.monotonic() - t_company)
            progress.write("running")
            beat(force=True, done=done, hits_total=progress.snapshot()["hits_total"], step="between companies")
            log(f"  -> {record.get('status')}  pages={record.get('pages_read', 0)}  windows={record.get('windows')}  "
                f"hits={record.get('hits')}")
    except (StoppedError, TimeBudgetError) as e:
        log(f"Stopping cleanly: {e}. Progress is saved; run again to resume.")
        events.info("runner_stopping", f"Stopping cleanly: {e}", reason=type(e).__name__)
        code = EXIT_STOPPED
    except KeyboardInterrupt:
        log("Interrupted. Progress is saved; run again to resume.")
        events.info("runner_stopping", "Interrupted; progress is saved", reason="KeyboardInterrupt")
        code = EXIT_STOPPED
    finally:
        retry_pending = sum(1 for c in companies if _retry_pending(state.get(c["company_id"])))
        summary = dict(rt.stats, finished_at=now_iso(), companies_processed=done, exit_code=code,
                       retry_pending=retry_pending, run_id=run_id)
        try:
            atomic_write_json(out / "run_summary.json", summary)
        except OSError:
            pass
        progress.write(_final_state(code, retry_pending), retry_pending=retry_pending, exit_code=code)
        events.emit("info" if code in (EXIT_OK, EXIT_STOPPED) else "error", "runner_finished",
                    f"Runner finished with exit code {code}: {done} companies processed this session",
                    exit_code=code, processed=done, retry_pending=retry_pending, stats=rt.stats)
        if client:
            client.unload()
    if code == EXIT_OK:
        log(f"Finished all due work ({done} companies). Model calls: {rt.stats['llm_calls']}, "
            f"cached: {rt.stats['cache_hits']}, hits: {rt.stats['hits']}")
    return code


def _retry_pending(record: Optional[Dict[str, Any]]) -> bool:
    """A company not yet in a final state that could still be retried (an unreachable site waiting for
    its next try). Reported so a finished run says plainly what a second run could still improve."""
    if record is None:
        return True
    if record.get("status") in TERMINAL_STATUSES:
        return False
    return int(record.get("attempts", 1)) < MAX_ATTEMPTS


def _record_company_events(events: EventLog, record: Dict[str, Any]) -> None:
    """The audit trail only carries what needs a person's attention or explains an outcome; a normal
    "done, nothing found" company is just a line in the outbox and the company table."""
    status = record.get("status")
    base = {"company_id": record.get("company_id"), "name": record.get("name"),
            "homepage_url": record.get("homepage_url"), "attempts": record.get("attempts")}
    if status == "site_unreachable":
        events.warn("site_unreachable", f"{record.get('name')}: site not readable ({record.get('site_detail')})",
                    detail=record.get("site_detail"), failed=record.get("pages_failed"), **base)
    elif status in ("blocked", "robots_blocked", "bad_homepage"):
        events.info("site_settled", f"{record.get('name')}: {status} ({record.get('site_detail')})",
                    status=status, detail=record.get("site_detail"), **base)
    elif status == "partial" and not record.get("error"):
        events.warn("company_partial", f"{record.get('name')}: the per-company time budget ran out before all passages were read",
                    seconds=record.get("seconds"), **base)
    if record.get("via") in ("wayback", "mixed"):
        events.info("archive_rescue", f"{record.get('name')}: read from the Wayback Machine because the live site failed",
                    via=record.get("via"), detail=record.get("site_detail"), pages=record.get("pages_read"), **base)


def _lower_priority() -> None:
    """Below-normal priority so the PC stays usable while this runs for days. Best effort."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)  # type: ignore[attr-defined]
    except Exception:
        pass


def main(argv: Optional[List[str]] = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass
    args = build_parser().parse_args(argv)
    try:
        return run(args)
    except Exception as e:  # anything run() itself did not foresee: leave evidence, then let the supervisor restart us
        print(traceback.format_exc(), flush=True)
        try:
            EventLog(Path(args.output_dir) / "events.jsonl", "runner", args.run_id).error(
                "runner_crashed", f"{type(e).__name__}: {e}"[:400], traceback=_traceback_tail(20))
        except Exception:
            pass
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
