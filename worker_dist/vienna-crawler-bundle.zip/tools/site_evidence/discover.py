"""Which pages of a company site are worth reading?

The existing company-website-crawler reads about / products / store locator / sustainability
and nothing else, so partner, research, project and news pages (where small manufacturers
actually mention universities and collaborations) were never read by anything. This module
scores every same-site link, and every sitemap URL, by what its path and anchor text say, in
Italian, English and German, and returns the few worth fetching. It is pure (no network), so it
is unit-tested on fixtures.

Two lessons from the first real-site trial are encoded here: short words are matched on word
boundaries (`r-?d` matched inside "standard" and made product pages look like research pages),
and sites that mirror every page in several languages are read in Italian first, English second
and never in other languages, because each translation would burn a slot of the page budget.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Dict, Iterable, List, Tuple
from urllib.parse import urlsplit

from .fetcher import same_site
from .gate import fold
from .text_extract import is_skippable_url

# (pattern on folded url-path + anchor text, weight). Weight 3 = names the very thing we look
# for; 2 = a page type that often mentions it (news, company history, certifications, case studies).
_POSITIVE: List[Tuple[re.Pattern, int]] = [(re.compile(p), w) for p, w in [
    (r"partner|collabor|kooperation|zusammenarbeit|alleanz|\bnetwork\b|\brete-|\breti-", 3),
    (r"ricerca|\bresearch\b|forschung|\br-?d\b|r-and-d|innovaz|innovation|innovativ", 3),
    (r"universit|politecnic|ateneo|laborator|laboratory|spin-?off|dottorat|\btesi\b", 3),
    (r"progett|\bproject|projekt|sviluppo|\bdevelopment\b|co-?design|co-?svilupp", 2),
    (r"success|\bstorie\b|case-?stud|referenz|\breferences?\b|\bclienti-e\b", 2),
    (r"\bnews\b|notizi|\bnovita\b|\bpress\b|\bstampa\b|\bmedia\b|comunicat|magazine|\beventi\b|\bevents\b|aktuell", 2),
    (r"\bazienda\b|\bcompany\b|\babout\b|chi-?siamo|\bstoria\b|\bhistory\b|unternehmen|ueber-uns|\bmission\b|\bvision\b|profilo|\bprofile\b|who-we-are", 2),
    (r"certific|\bqualit|accredit|\bpremio\b|\bpremi\b|\bawards?\b|riconoscimenti", 2),
    (r"\bexport\b|internaz|international|\bmondo\b|\bworld\b|\bglobal\b|worldwide|\bmercati\b|\bmarkets\b|presenza", 2),
    (r"sostenib|sustainab|\bcsr\b|\besg\b|\bambiente\b|nachhaltig", 1),
]]
_NEGATIVE: List[Tuple[re.Pattern, int]] = [(re.compile(p), w) for p, w in [
    (r"privacy|cookie|gdpr|terms|condizioni|disclaimer|impressum|login|account|my-account|cart|carrello|checkout|wishlist|webmail", -6),
    (r"lavora-con-noi|work-with-us|careers?|jobs?|stellenangebote|candidatur|offerte-di-lavoro", -3),
    (r"contatt|contact|kontakt|dove-siamo|where-to-find|sitemap|mappa-del-sito", -2),
    (r"/(tag|tags|category|categoria|author|autore|feed|wp-json|wp-admin|cdn-cgi)/", -4),
    (r"[?&](replytocom|share|print)=", -4),
    (r"/wp-content/|/uploads/|/wp-includes/|/assets/|/static/|/images?/|/img/", -6),
]]
_PAGINATION = re.compile(r"/(page|pagina)/\d+|[?&]paged?=\d+")

# Language mirrors. The cohort is Italian: Italian first, English second (a small penalty),
# every other language never.
_LANGUAGE_CODES = {
    "it", "en", "de", "fr", "es", "pt", "ru", "zh", "ja", "nl", "pl", "cs", "hu", "ro", "tr", "ar", "sv", "da",
    "fi", "no", "el", "bg", "sk", "sl", "hr", "sr", "uk", "ko", "he", "hi", "lt", "lv", "et", "ca", "th", "vi",
}
_LANG_SEGMENT = re.compile(r"^([a-z]{2})(?:[-_][a-z]{2})?$")


def url_language(url: str):
    """The language code of a `/xx/...` path prefix, or None when the URL has none."""
    first = next((seg for seg in urlsplit(url).path.lower().split("/") if seg), "")
    m = _LANG_SEGMENT.match(first)
    return m.group(1) if m and m.group(1) in _LANGUAGE_CODES else None


def language_adjustment(url: str, allowed: Tuple[str, ...] = ("it", "en")) -> int:
    lang = url_language(url)
    if lang is None or lang == allowed[0]:
        return 0
    return -1 if lang in allowed else -99


def score_url(url: str, anchor: str = "") -> int:
    parts = urlsplit(url)
    text = fold(f"{parts.path} {parts.query} {anchor}")
    score = 0
    for pattern, weight in _POSITIVE:
        if pattern.search(text):
            score += weight
    for pattern, weight in _NEGATIVE:
        if pattern.search(text):
            score += weight
    if _PAGINATION.search(text):
        score -= 3
    depth = len([s for s in parts.path.split("/") if s])
    if depth > 5:
        score -= 1
    return score


def rank_candidates(base_url: str, links: Iterable[Tuple[str, str]], min_score: int = 2,
                    exclude: Iterable[str] = ()) -> List[Tuple[int, str]]:
    """Same-site links scored; best first; ties broken by shorter path (hub pages beat deep ones)."""
    skip = set(exclude)
    scored: Dict[str, int] = {}
    for url, anchor in links:
        if url in skip or not same_site(base_url, url) or is_skippable_url(url):
            continue
        s = score_url(url, anchor) + language_adjustment(url)
        if s >= min_score and s > scored.get(url, -99):
            scored[url] = s
    return sorted(((s, u) for u, s in scored.items()), key=lambda t: (-t[0], len(urlsplit(t[1]).path), t[1]))


def parse_sitemap(xml_text: str, limit: int = 600) -> Tuple[List[str], List[str]]:
    """(page urls, child sitemap urls) from a sitemap or sitemap index. Never raises."""
    pages: List[str] = []
    children: List[str] = []
    try:
        root = ET.fromstring(xml_text.strip())
    except ET.ParseError:
        return pages, children
    for el in root.iter():
        tag = el.tag.rsplit("}", 1)[-1]
        if tag == "loc" and el.text:
            loc = el.text.strip()
            if loc.endswith((".xml", ".xml.gz")):
                children.append(loc)
            else:
                pages.append(loc)
            if len(pages) >= limit:
                break
    return pages, children
