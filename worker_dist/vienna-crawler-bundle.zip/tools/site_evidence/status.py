"""One-screen status of a (possibly days-long) run, readable while it runs.

    python -m tools.site_evidence.status [--output-dir <folder>] [--input <companies.csv>]

Everything comes from the files the runner already keeps (heartbeat.json, state.json, results.jsonl,
run.log), so asking never disturbs the job.
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from .runner import DEFAULT_OUTPUT_DIR, due, load_companies
from .store import State, load_json_with_backup, read_jsonl
from .supervisor import heartbeat_age_minutes, pid_alive


def _pid(path: Path) -> int:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return 0


def render(out: Path, input_csv: Optional[Path] = None) -> str:
    lines: List[str] = []
    sup, run = _pid(out / "supervisor.pid"), _pid(out / "runner.pid")
    hb = load_json_with_backup(out / "heartbeat.json", {}) or {}
    age = heartbeat_age_minutes(out)
    state = State(out / "state.json").data
    hits = list(read_jsonl(out / "results.jsonl"))

    if (out / "STOP").exists():
        lines.append("STOP file present: the job will not (re)start until it is deleted.")
    running = pid_alive(run) if run else False
    lines.append(f"Supervisor: {'running (pid %d)' % sup if sup and pid_alive(sup) else 'not running'}   "
                 f"Runner: {'running (pid %d)' % run if running else 'not running'}")
    if hb:
        lines.append(f"Now: {hb.get('name') or '-'}  [{hb.get('step') or '-'}]"
                     f"{'  WAITING FOR ' + str(hb['waiting_for']).upper() if hb.get('waiting_for') else ''}"
                     f"   (heartbeat {age:.1f} min ago)" if age is not None else f"Now: {hb.get('name') or '-'}")

    total = None
    if input_csv and Path(input_csv).exists():
        companies = load_companies(Path(input_csv))
        total = len(companies)
        import time as _t
        now = _t.time()
        lines.append(f"Companies: {total} in the list, {sum(1 for c in companies if due(state.get(c['company_id']), now))} still due")
    statuses = Counter(rec.get("status") for rec in state.values())
    lines.append(f"Processed: {len(state)}   by status: {dict(statuses)}")

    secs = [float(r["seconds"]) for r in state.values() if r.get("seconds")]
    if secs:
        mean = sum(secs) / len(secs)
        lines.append(f"Average {mean:.0f} s of work per company" +
                     (f"; about {(total - len(state)) * mean / 3600:.1f} hours of work left" if total else ""))
    by_claim = Counter(h.get("claim") for h in hits)
    lines.append(f"Confirmed quotes: {len(hits)} in {len({h.get('company_id') for h in hits})} companies   by claim: {dict(by_claim)}")
    summary = load_json_with_backup(out / "run_summary.json", {}) or {}
    if summary:
        lines.append(f"Last run: {summary.get('llm_calls', 0)} model calls, {summary.get('cache_hits', 0)} from cache, "
                     f"{summary.get('rejected_not_verbatim', 0)} quotes rejected as not verbatim, "
                     f"{summary.get('rejected_rules', 0)} by the claim rules")
    log = out / "run.log"
    if log.exists():
        tail = log.read_text(encoding="utf-8", errors="replace").splitlines()[-3:]
        lines.append("Log tail:")
        lines.extend("  " + ln[:200] for ln in tail)
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Status of the site-evidence run.")
    ap.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    ap.add_argument("--input", default=None, help="companies.csv, to show how much is left")
    args = ap.parse_args(argv)
    out = Path(args.output_dir)
    inp = Path(args.input) if args.input else (out / "companies.csv")
    print(render(out, inp if inp.exists() else None))
    return 0


if __name__ == "__main__":
    sys.exit(main())
