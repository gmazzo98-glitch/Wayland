"""Which exact code produced a result. The audit trail records this on every run, so a finding (or a
failure) can always be traced to the tool version that made it, without trusting a version number
someone has to remember to bump."""
from __future__ import annotations

import hashlib
import platform
import sys
from pathlib import Path
from typing import Any, Dict

from .claims import RULES_VERSION

_PACKAGE_DIR = Path(__file__).resolve().parent


def tool_build() -> str:
    """A short content hash of the tool's own Python files (line endings ignored)."""
    digest = hashlib.sha256()
    for path in sorted(_PACKAGE_DIR.glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes().replace(b"\r\n", b"\n"))
    return digest.hexdigest()[:12]


def environment() -> Dict[str, Any]:
    return {
        "tool_build": tool_build(), "rules_version": RULES_VERSION,
        "python": sys.version.split()[0], "platform": platform.platform(), "host": platform.node(),
        "tool_dir": str(_PACKAGE_DIR),
    }
