"""Turn fetched pages into the few short passages worth a model call.

A small site yields 10-15 pages and tens of thousands of characters, almost all of it navigation,
product copy and legal text. Sending that to a 3B model at ~40 s per call would take days per
company and drown the one sentence that matters, so: strip boilerplate shared by many pages of
the same site, then keep only passages where a claim's keyword trigger AND all of its required
vocabularies appear together. Most claims on most companies produce zero passages, which is the
point: the model's time goes to the handful of passages that could actually be evidence.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Dict, List

from .claims import Claim
from .gate import fold

_COOKIE_LINE = re.compile(r"cookie|gdpr|privacy policy|informativa|accetta|consenso|consent|tutti i diritti riservati|"
                          r"all rights reserved|p\.? ?iva|partita iva|capitale sociale|cookiebot|iubenda")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?;])\s+(?=[A-Z0-9À-Ý\"'«])")


@dataclass(frozen=True)
class Window:
    url: str
    text: str
    score: int


def strip_boilerplate(pages: Dict[str, str]) -> Dict[str, List[str]]:
    """url -> lines, with menu/footer/cookie lines that repeat across the site removed."""
    lines_by_url = {u: [ln for ln in t.split("\n") if ln.strip()] for u, t in pages.items()}
    n_pages = len(lines_by_url)
    counts: Counter = Counter()
    for lines in lines_by_url.values():
        for ln in {fold(x) for x in lines}:
            counts[ln] += 1
    out: Dict[str, List[str]] = {}
    for url, lines in lines_by_url.items():
        kept = []
        for ln in lines:
            f = fold(ln)
            if len(ln) <= 260 and _COOKIE_LINE.search(f):
                continue
            if n_pages >= 3 and len(ln) <= 220 and counts[f] >= 3 and counts[f] / n_pages >= 0.4:
                continue
            kept.append(ln)
        out[url] = kept
    return out


def split_sentences(text: str) -> List[str]:
    parts = [s.strip() for s in _SENTENCE_SPLIT.split(text) if s.strip()]
    return parts or ([text.strip()] if text.strip() else [])


def _trim(text: str, max_chars: int, anchor: re.Pattern) -> str:
    if len(text) <= max_chars:
        return text
    m = anchor.search(fold(text))
    centre = m.start() if m else len(text) // 2
    start = max(0, min(centre - max_chars // 2, len(text) - max_chars))
    chunk = text[start: start + max_chars]
    # Cut on sentence-ish boundaries so the model is not handed half a sentence at either end.
    first = re.search(r"[.!?;]\s+", chunk[:160])
    if first and start > 0:
        chunk = chunk[first.end():]
    last = max(chunk.rfind(". "), chunk.rfind("; "), chunk.rfind("! "), chunk.rfind("? "))
    if last > len(chunk) * 0.6 and start + max_chars < len(text):
        chunk = chunk[: last + 1]
    return chunk.strip()


def find_windows(lines_by_url: Dict[str, List[str]], claim: Claim, max_chars: int = 700) -> List[Window]:
    found: Dict[str, Window] = {}
    for url, lines in lines_by_url.items():
        for i, line in enumerate(lines):
            if not claim.triggers.search(fold(line)):
                continue
            parts = [line]
            if len(line) < 200:  # a short trigger line (a heading, a list item) needs its neighbours
                if i > 0:
                    parts.insert(0, lines[i - 1])
                if i + 1 < len(lines):
                    parts.append(lines[i + 1])
            text = _trim(" ".join(parts), max_chars, claim.triggers)
            if not claim.passage_ok(text):
                continue
            f = fold(text)
            score = len(claim.triggers.findall(f)) + sum(1 for r in claim.require if r.search(f))
            key = f
            if key not in found or found[key].score < score:
                found[key] = Window(url=url, text=text, score=score)
    ranked = sorted(found.values(), key=lambda w: (-w.score, w.url, w.text))
    return ranked[: claim.max_windows]
