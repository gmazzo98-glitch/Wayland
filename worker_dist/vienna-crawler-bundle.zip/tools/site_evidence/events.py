"""The audit trail: an append-only event log that survives everything, written by the runner, the
supervisor and (from the Vienna worker) the worker, and read by whoever needs to know what happened.

Why a separate log and not just run.log: run.log is free text for a human at a console. This is
structured, one JSON object per line, with a stable `code` per kind of event, so that (a) the Vienna
worker can forward it to the database in idempotent batches (every event has a unique id), and (b) a
failed run can be diagnosed from data rather than from scrolling a log.

An event never raises: a full disk or a locked file must not stop a multi-day job. Long strings and
lists are clipped so one runaway traceback cannot bloat the database.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from .store import append_jsonl

LEVELS = ("info", "warn", "error")
MAX_STRING = 2000
MAX_ITEMS = 40
MAX_DATA_CHARS = 8000


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def clip(value: Any, depth: int = 0, max_items: int = MAX_ITEMS, max_string: int = MAX_STRING,
         max_depth: int = 4) -> Any:
    """A copy of `value` with long strings, long lists and deep nesting cut down."""
    if depth > max_depth:
        return "<nested too deep>"
    if isinstance(value, str):
        return value if len(value) <= max_string else value[:max_string] + f"...[{len(value) - max_string} more chars]"
    if isinstance(value, dict):
        return {str(k)[:80]: clip(v, depth + 1, max_items, max_string, max_depth) for k, v in list(value.items())[:max_items]}
    if isinstance(value, (list, tuple)):
        items = [clip(v, depth + 1, max_items, max_string, max_depth) for v in list(value)[:max_items]]
        if len(value) > max_items:
            items.append(f"...[{len(value) - max_items} more items]")
        return items
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)[:max_string]


class EventLog:
    def __init__(self, path: Path, source: str, run_id: str = "local",
                 clock: Callable[[], str] = now_iso, new_id: Callable[[], str] = lambda: uuid.uuid4().hex):
        self.path = Path(path)
        self.source = source
        self.run_id = run_id or "local"
        self._clock, self._new_id = clock, new_id
        self._throttle: Dict[str, float] = {}

    def emit(self, level: str, code: str, message: str, **data: Any) -> Dict[str, Any]:
        event: Dict[str, Any] = {
            "id": self._new_id(), "ts": self._clock(), "source": self.source, "run_id": self.run_id,
            "level": level if level in LEVELS else "info", "code": code, "message": str(message)[:600],
            "data": clip(data),
        }
        if len(json.dumps(event["data"], default=str)) > MAX_DATA_CHARS:
            event["data"] = {"truncated": json.dumps(event["data"], default=str)[:MAX_DATA_CHARS]}
        try:
            append_jsonl(self.path, event)
        except OSError:
            pass  # the audit log must never be the reason a job stops
        return event

    def info(self, code: str, message: str, **data: Any) -> Dict[str, Any]:
        return self.emit("info", code, message, **data)

    def warn(self, code: str, message: str, **data: Any) -> Dict[str, Any]:
        return self.emit("warn", code, message, **data)

    def error(self, code: str, message: str, **data: Any) -> Dict[str, Any]:
        return self.emit("error", code, message, **data)

    def throttled(self, key: str, interval_s: float, now: float, level: str, code: str, message: str,
                  **data: Any) -> Optional[Dict[str, Any]]:
        """Emit at most once per `interval_s` for `key` (a retry loop must not write a line a minute
        for a week). Returns the event, or None when suppressed."""
        last = self._throttle.get(key)
        if last is not None and now - last < interval_s:
            return None
        self._throttle[key] = now
        return self.emit(level, code, message, **data)
