"""One company's confirmed findings -> the Vienna signals they become.

This is the same mapping Project Vienna's scrapers/site_evidence_reader.py applies when importing a
results folder by hand; it lives here as well because, when the run is started from the Vienna app,
the Vienna worker ships ready-made signals to the database (the worker holds no database password and
the database function only stores and guards them, it does not interpret findings). A parity test in
the Vienna repo compares the two implementations on the same fixtures so they cannot drift apart.

Only positive, quote-verified findings are ever turned into signals. "Nothing found" is never recorded
as "absent": a company can collaborate with a university without saying so on its website.

Existing Vienna indicators only, no new keys, no weight changes:
    university_partnership -> university_partnership          (value 1.0)
    external_collaboration -> external_collaboration          (value 1.0)
    open_innovation        -> prior_open_innovation_usage     (value 1.0)
    export_share_pct       -> international_sales_volume      (value = the stated percentage)
    export_since_year      -> years_international_activity    (value = this year - the stated year)
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

from .claims import RULES_VERSION

CONFIDENCE_LIVE = 0.6      # a verified quote from the company's own live page
CONFIDENCE_ARCHIVE = 0.45  # the same, read from an archived copy because the live site failed

CLAIM_TO_SIGNAL = {
    "university_partnership": "university_partnership",
    "external_collaboration": "external_collaboration",
    "open_innovation": "prior_open_innovation_usage",
    "export_share_pct": "international_sales_volume",
    "export_since_year": "years_international_activity",
}


def _short(text: str, n: int = 150) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= n else text[: n - 1].rstrip() + "..."


def _hint(hit: Dict[str, Any]) -> Optional[str]:
    return hit.get("institution_hint") or hit.get("partner_hint") or hit.get("program_hint")


def derive_signals(hits: Iterable[Dict[str, Any]], year_now: Optional[int] = None) -> List[Dict[str, Any]]:
    """If a claim was found more than once (live and archived copies, or a re-run), the live one wins,
    then the earliest found, so re-importing never changes a signal for no reason."""
    year_now = year_now or datetime.now(timezone.utc).year
    best: Dict[str, Any] = {}
    for hit in hits:
        claim = hit.get("claim")
        if claim not in CLAIM_TO_SIGNAL or not (hit.get("quote") or "").strip():
            continue
        if int(hit.get("rules_version") or 1) < RULES_VERSION:
            continue
        rank = (0 if hit.get("via") == "live" else 1, hit.get("found_at") or "")
        if claim not in best or rank < best[claim][0]:
            best[claim] = (rank, hit)

    out: List[Dict[str, Any]] = []
    for claim, (_, hit) in sorted(best.items()):
        key = CLAIM_TO_SIGNAL[claim]
        archived = hit.get("via") == "wayback"
        if claim in ("export_share_pct", "export_since_year"):
            raw = hit.get("value")
            if raw is None:
                continue
            if claim == "export_share_pct":
                value = float(raw)
                summary = f"own site states {value:.0f}% of sales/production goes abroad"
            else:
                value = float(year_now - int(raw))
                if value < 0:
                    continue
                summary = f"own site states exporting/operating abroad since {int(raw)}"
        else:
            value = 1.0
            hint = _hint(hit)
            label = {"university_partnership": "university/research partnership",
                     "external_collaboration": "external collaboration",
                     "open_innovation": "innovation programme or award"}[claim]
            summary = f"own site documents a {label}" + (f" ({_short(hint, 60)})" if hint else "")
        if archived:
            ts = hit.get("snapshot_ts") or ""
            summary += f" [archived copy of {ts[:4]}-{ts[4:6]}-{ts[6:8]}]" if len(ts) >= 8 else " [archived copy]"
        summary += f': "{_short(hit["quote"])}"'

        dating = hit.get("first_seen") or {}
        evidence = {
            "method": "local model proposed one verbatim sentence from the company's own site; code verified it "
                      "is on the page and passes the claim's rules",
            "source_urls": [hit.get("page_url")] if hit.get("page_url") else [],
            "quote": hit["quote"], "page_title": hit.get("page_title"),
            "page_read": "archived copy (live site unreadable)" if archived else "live",
            "snapshot_ts": hit.get("snapshot_ts"), "model": hit.get("model"), "num_ctx": hit.get("num_ctx"),
            "found_at": hit.get("found_at"), "claim": claim, "hint": _hint(hit),
            "rules_version": hit.get("rules_version"),
        }
        if dating.get("status") in ("ok", "bounded"):
            evidence["first_seen_in_archive"] = {
                "date": dating.get("first_seen_date"), "replay_url": dating.get("replay_url"),
                "note": dating.get("note"), "earliest_archived": dating.get("earliest_archived"),
            }
            summary += f" (same text archived since {dating.get('first_seen_date')})"
        out.append({
            "signal_key": key, "value": value, "status": "present", "summary": summary, "evidence": evidence,
            "confidence": CONFIDENCE_ARCHIVE if archived else CONFIDENCE_LIVE,
        })
    return out
