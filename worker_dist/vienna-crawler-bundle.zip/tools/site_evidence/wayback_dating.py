"""Two ways the Wayback Machine helps this tool, both deterministic (no model involved):

  1. RESCUE. When a company's live site cannot be read (expired/broken TLS certificate, DNS or
     connection failure, timeout), read its most recent archived copy instead. Evidence read this
     way is labelled `via: wayback` with the snapshot date, and the claims it supports ("worked
     with a university", "took part in a programme") are track-record facts, which an archived
     page still evidences. robots.txt-disallowed and bot-blocked sites are never rescued this way:
     the archive is not a way around a site owner saying no.

  2. DATING. Once a quote has been confirmed on a page, find the earliest archived snapshot of
     that same page that contains the same wording, by bisection over the page's snapshot list
     (about log2(N) fetches, ~15 s per hit at the archive's polite pace). That turns "the site
     mentions a university partnership" into "the site has said so since at least <date>", and
     for the export claims a stated-since year can be cross-checked against it.

Everything else about the old wayback_timeline tool (walking every snapshot with the model) is not
used: it cost ~40 s per snapshot, and its answers were in a file nothing read.

Same politeness as tools/wayback_timeline/wayback_client.py (identifying user agent, >=2 s between
requests, id_ raw snapshots), reimplemented here so this tool has no dependency on that one.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional
from urllib.parse import urlencode

from .gate import quote_verified
from .text_extract import html_to_text

USER_AGENT = "ProjectViennaBot/1.0 (site-evidence tool; contact gio3maz@gmail.com)"
CDX_ENDPOINT = "https://web.archive.org/cdx/search/cdx"


@dataclass(frozen=True)
class Capture:
    timestamp: str  # YYYYMMDDhhmmss
    original: str

    @property
    def date(self) -> str:
        return f"{self.timestamp[:4]}-{self.timestamp[4:6]}-{self.timestamp[6:8]}"

    @property
    def raw_url(self) -> str:
        # The id_ suffix returns the original bytes; the plain pattern injects the archive's toolbar.
        return f"https://web.archive.org/web/{self.timestamp}id_/{self.original}"

    @property
    def replay_url(self) -> str:
        return f"https://web.archive.org/web/{self.timestamp}/{self.original}"


class WaybackError(RuntimeError):
    pass


@dataclass
class WaybackClient:
    delay_s: float = 2.0
    timeout_s: float = 40.0
    retries: int = 2
    sleep: Callable[[float], None] = field(default=time.sleep)
    opener: Callable = field(default=urllib.request.urlopen)
    requests_made: int = 0

    def _get(self, url: str) -> str:
        last: Optional[Exception] = None
        for attempt in range(self.retries + 1):
            if attempt:
                self.sleep(min(4 * 2 ** attempt, 30))
            self.sleep(self.delay_s)
            self.requests_made += 1
            try:
                req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                with self.opener(req, timeout=self.timeout_s) as resp:
                    return resp.read().decode("utf-8", errors="replace")
            except urllib.error.HTTPError as e:
                if e.code in (404, 410):
                    raise WaybackError(f"HTTP {e.code}")
                last = e
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                last = e
        raise WaybackError(f"archive request failed after {self.retries + 1} attempts: {last}")

    def captures(self, url: str, monthly: bool = True, limit: int = 3000) -> List[Capture]:
        params = {"url": url, "output": "json", "fl": "timestamp,original", "filter": "statuscode:200", "limit": str(limit)}
        if monthly:
            params["collapse"] = "timestamp:6"
        body = self._get(f"{CDX_ENDPOINT}?{urlencode(params)}")
        if not body.strip():
            return []
        rows = json.loads(body)
        return [Capture(timestamp=r[0], original=r[1]) for r in rows[1:]]

    def latest(self, url: str) -> Optional[Capture]:
        params = {"url": url, "output": "json", "fl": "timestamp,original", "filter": "statuscode:200", "limit": "-1"}
        body = self._get(f"{CDX_ENDPOINT}?{urlencode(params)}")
        if not body.strip():
            return None
        rows = json.loads(body)
        return Capture(timestamp=rows[-1][0], original=rows[-1][1]) if len(rows) > 1 else None

    def fetch(self, capture: Capture) -> str:
        return self._get(capture.raw_url)


def first_seen(client: WaybackClient, page_url: str, quote: str, max_fetches: int = 9) -> Dict:
    """Earliest archived snapshot of `page_url` whose text contains `quote` (same gate as live
    evidence). Bisection assumes a claim, once added to a page, mostly stays there; the result is
    therefore worded "earliest archived snapshot containing this exact text", never "the date it
    was published". Never raises: failures come back as a status."""
    try:
        caps = client.captures(page_url)
    except (WaybackError, ValueError) as e:
        return {"status": "archive_error", "detail": str(e)[:160]}
    if not caps:
        return {"status": "no_captures", "captures_total": 0}

    fetched: Dict[int, Optional[bool]] = {}

    def contains(i: int) -> Optional[bool]:
        if i in fetched:
            return fetched[i]
        if len(fetched) >= max_fetches:
            return None
        try:
            fetched[i] = quote_verified(quote, html_to_text(client.fetch(caps[i])))
        except (WaybackError, ValueError):
            fetched[i] = None
        return fetched[i]

    last = len(caps) - 1
    anchor = contains(last)
    if anchor is None:
        return {"status": "archive_error", "captures_total": len(caps), "detail": "latest snapshot unreadable"}
    if anchor is False:
        # The wording is on the live page but not in the newest archived copy: the archive is
        # older than the text, or the text moved. Say so instead of guessing.
        return {"status": "not_in_latest_archive", "captures_total": len(caps),
                "latest_archived": caps[last].date}
    lo, hi = 0, last
    while lo < hi:
        mid = (lo + hi) // 2
        found = contains(mid)
        if found is None:  # unreadable or out of budget: this is as far as we can safely say
            break
        if found:
            hi = mid
        else:
            lo = mid + 1
    exact = lo == hi
    cap = caps[hi]
    return {
        "status": "ok" if exact else "bounded",
        "first_seen_ts": cap.timestamp, "first_seen_date": cap.date, "replay_url": cap.replay_url,
        "captures_total": len(caps), "snapshots_read": len(fetched),
        "earliest_archived": caps[0].date,
        "note": ("earliest archived snapshot containing this exact text" if exact
                 else "no later than this date (bisection stopped early)"),
    }
