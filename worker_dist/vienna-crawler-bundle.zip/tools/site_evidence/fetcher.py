"""Polite page fetching, standard library only.

What "polite" means here, because this tool reads other people's websites for days:
  - an honest user agent with a contact address (same convention as the Wayback tool);
  - robots.txt is fetched once per host and obeyed, per path;
  - at least `delay_s` seconds between two requests to the same host;
  - no logins, no CAPTCHA solving, no retry hammering: at most one retry, and only for
    transient errors;
  - TLS is always verified. A site whose certificate fails is reported as 'tls' and the caller
    may read the archived copy instead; it is never fetched insecurely.

Every outcome is classified into a small set of `kind`s so the runner can decide what is worth
retrying later (dns/timeout/conn/tls/http-5xx) and what is a settled answer (robots, blocked,
not found).
"""
from __future__ import annotations

import re
import socket
import ssl
import time
import urllib.error
import urllib.request
import urllib.robotparser
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional
from urllib.parse import urlsplit

USER_AGENT = "ProjectViennaBot/1.0 (site-evidence tool; contact gio3maz@gmail.com)"
ROBOTS_TOKEN = "ProjectViennaBot"

RETRYABLE_KINDS = {"dns", "timeout", "conn", "tls", "server"}
SETTLED_KINDS = {"robots", "blocked", "notfound", "not_html"}


@dataclass
class FetchResult:
    url: str
    ok: bool
    kind: str  # ok | robots | blocked | notfound | server | tls | dns | timeout | conn | not_html | error
    status: Optional[int] = None
    final_url: Optional[str] = None
    html: str = ""
    detail: str = ""
    truncated: bool = False

    @property
    def retryable(self) -> bool:
        return self.kind in RETRYABLE_KINDS


def host_of(url: str) -> str:
    return (urlsplit(url).hostname or "").lower()


def same_site(a: str, b: str) -> bool:
    ha, hb = host_of(a), host_of(b)
    if not ha or not hb:
        return False
    ha = ha[4:] if ha.startswith("www.") else ha
    hb = hb[4:] if hb.startswith("www.") else hb
    return ha == hb or ha.endswith("." + hb) or hb.endswith("." + ha)


def _classify_exception(exc: BaseException) -> tuple[str, str]:
    reason = getattr(exc, "reason", exc)
    if isinstance(reason, (ssl.SSLError, ssl.CertificateError)):
        return "tls", str(reason)[:200]
    if isinstance(reason, socket.gaierror):
        return "dns", str(reason)[:200]
    if isinstance(reason, (socket.timeout, TimeoutError)):
        return "timeout", str(reason)[:200]
    if isinstance(reason, (ConnectionError, OSError)):
        return "conn", str(reason)[:200]
    text = str(reason)
    if "timed out" in text.lower():
        return "timeout", text[:200]
    return "error", f"{type(reason).__name__}: {text}"[:200]


def _decode(body: bytes, content_type: str) -> str:
    charset = None
    m = re.search(r"charset=([\w\-]+)", content_type or "", re.IGNORECASE)
    if m:
        charset = m.group(1)
    if not charset:
        m = re.search(rb"<meta[^>]+charset=[\"']?([\w\-]+)", body[:4096], re.IGNORECASE)
        if m:
            charset = m.group(1).decode("ascii", "ignore")
    for enc in (charset, "utf-8"):
        if not enc:
            continue
        try:
            return body.decode(enc, errors="replace")
        except LookupError:
            continue
    return body.decode("utf-8", errors="replace")


@dataclass
class Fetcher:
    delay_s: float = 2.0
    timeout_s: float = 25.0
    max_bytes: int = 2_000_000
    user_agent: str = USER_AGENT
    sleep: Callable[[float], None] = field(default=time.sleep)
    clock: Callable[[], float] = field(default=time.monotonic)
    # `opener(request, timeout)` -> response object; injectable so tests need no network.
    opener: Callable = field(default=urllib.request.urlopen)
    _last_hit: Dict[str, float] = field(default_factory=dict)
    _robots: Dict[str, Optional[urllib.robotparser.RobotFileParser]] = field(default_factory=dict)
    _sitemaps: Dict[str, List[str]] = field(default_factory=dict)
    requests_made: int = 0

    def _pace(self, host: str) -> None:
        last = self._last_hit.get(host)
        if last is not None:
            wait = self.delay_s - (self.clock() - last)
            if wait > 0:
                self.sleep(wait)
        self._last_hit[host] = self.clock()

    def _request(self, url: str, accept: str = "text/html,application/xhtml+xml,text/plain;q=0.8,*/*;q=0.5"):
        req = urllib.request.Request(url, headers={
            "User-Agent": self.user_agent, "Accept": accept,
            "Accept-Language": "it,en;q=0.8,de;q=0.6",
        })
        self.requests_made += 1
        return self.opener(req, timeout=self.timeout_s)

    # -- robots.txt -------------------------------------------------------------------------
    def _load_robots(self, url: str) -> None:
        parts = urlsplit(url)
        host = parts.netloc.lower()
        if host in self._robots:
            return
        robots_url = f"{parts.scheme}://{parts.netloc}/robots.txt"
        parser: Optional[urllib.robotparser.RobotFileParser] = None
        self._sitemaps[host] = []
        try:
            self._pace(host)
            with self._request(robots_url, accept="text/plain,*/*;q=0.5") as resp:
                body = resp.read(300_000)
                status = getattr(resp, "status", 200)
            if status == 200:
                parser = urllib.robotparser.RobotFileParser()
                parser.parse(body.decode("utf-8", errors="replace").splitlines())
                self._sitemaps[host] = list(parser.site_maps() or [])
        except Exception:
            parser = None  # 4xx/5xx/unreachable robots.txt: treated as "no rules", as search engines do
        self._robots[host] = parser

    def allowed(self, url: str) -> bool:
        self._load_robots(url)
        parser = self._robots.get(urlsplit(url).netloc.lower())
        if parser is None:
            return True
        try:
            return parser.can_fetch(ROBOTS_TOKEN, url)
        except Exception:
            return True

    def sitemaps(self, url: str) -> List[str]:
        self._load_robots(url)
        return list(self._sitemaps.get(urlsplit(url).netloc.lower(), []))

    # -- the fetch ------------------------------------------------------------------------
    def get(self, url: str, check_robots: bool = True, _retry: bool = True) -> FetchResult:
        if check_robots and not self.allowed(url):
            return FetchResult(url=url, ok=False, kind="robots", detail="disallowed by robots.txt")
        self._pace(host_of(url))
        try:
            with self._request(url) as resp:
                status = getattr(resp, "status", 200)
                ctype = resp.headers.get("Content-Type", "") if getattr(resp, "headers", None) else ""
                final_url = resp.geturl() if hasattr(resp, "geturl") else url
                if ctype and not re.search(r"html|xml|text/plain", ctype, re.IGNORECASE):
                    return FetchResult(url=url, ok=False, kind="not_html", status=status,
                                       final_url=final_url, detail=ctype[:80])
                body = resp.read(self.max_bytes + 1)
            if b"\x00" in body[:4096]:  # an image or archive served with a missing/wrong content type
                return FetchResult(url=url, ok=False, kind="not_html", status=status, final_url=final_url,
                                   detail="binary body")
            truncated = len(body) > self.max_bytes
            return FetchResult(url=url, ok=True, kind="ok", status=status, final_url=final_url,
                               html=_decode(body[: self.max_bytes], ctype), truncated=truncated)
        except urllib.error.HTTPError as e:
            code = e.code
            if code in (429, 503) and _retry:
                retry_after = e.headers.get("Retry-After", "") if e.headers else ""
                self.sleep(min(float(retry_after), 30.0) if retry_after.isdigit() else 8.0)
                return self.get(url, check_robots=False, _retry=False)
            if code in (401, 403, 406, 429, 451):
                return FetchResult(url=url, ok=False, kind="blocked", status=code, detail=f"HTTP {code}")
            if code in (404, 410):
                return FetchResult(url=url, ok=False, kind="notfound", status=code, detail=f"HTTP {code}")
            return FetchResult(url=url, ok=False, kind="server" if code >= 500 else "error",
                               status=code, detail=f"HTTP {code}")
        except Exception as e:  # URLError, timeouts, resets, incomplete reads, bad redirects
            kind, detail = _classify_exception(e)
            if kind in ("timeout", "conn") and _retry:
                self.sleep(3.0)
                return self.get(url, check_robots=False, _retry=False)
            return FetchResult(url=url, ok=False, kind=kind, detail=detail)

    def get_text(self, url: str, max_bytes: int = 600_000) -> FetchResult:
        """For sitemap XML: same pacing and politeness, no robots check (a sitemap is an
        invitation), bigger tolerance for non-HTML content types."""
        self._pace(host_of(url))
        try:
            with self._request(url, accept="application/xml,text/xml,text/plain,*/*;q=0.5") as resp:
                body = resp.read(max_bytes)
                ctype = resp.headers.get("Content-Type", "") if getattr(resp, "headers", None) else ""
            return FetchResult(url=url, ok=True, kind="ok", html=_decode(body, ctype))
        except urllib.error.HTTPError as e:
            return FetchResult(url=url, ok=False, kind="notfound" if e.code in (404, 410) else "error",
                               status=e.code, detail=f"HTTP {e.code}")
        except Exception as e:
            kind, detail = _classify_exception(e)
            return FetchResult(url=url, ok=False, kind=kind, detail=detail)
