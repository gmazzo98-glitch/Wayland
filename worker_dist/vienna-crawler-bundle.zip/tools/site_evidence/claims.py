"""The claims this tool looks for, and the deterministic rules that decide whether a quote counts.

Division of labour, learned the hard way in the Wayback pilot and the Verdantex harvester:
  - code PRE-SELECTS candidate passages with cheap keyword triggers (so the slow local model
    only ever reads a few hundred characters that could plausibly matter);
  - the model PROPOSES one verbatim sentence or null (quote-or-null; never asked for a true/false
    judgment, which a 3B model gets wrong even when its own quote is right);
  - code DECIDES: the quote must be a verbatim substring of the page (gate.py) AND satisfy the
    claim's own rules below. Both keys must turn, so a model slip becomes a missed lead, never a
    false signal.

Each claim maps to ONE existing indicator (no new signal keys, no weight changes):
  university_partnership   -> university_partnership        (weight 5, readiness)
  external_collaboration   -> external_collaboration        (weight 5, readiness)
  open_innovation          -> prior_open_innovation_usage   (weight 4, readiness)
  export_share_pct         -> international_sales_volume    (weight 3, need)
  export_since_year        -> years_international_activity  (weight 2, need)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from .gate import fold


# Bump whenever a rule gets STRICTER. Every finding is stamped with the version that accepted it, and the
# Vienna importer refuses findings older than the version it requires, so a tightened rule can never be
# bypassed by a results file written before the tightening. (v2: named partner/institution required.)
RULES_VERSION = 4
# (v2: a named partner/institution is required. v3: a quote must sit inside one page line, dated export
#  figures older than three years are refused, training/sponsorship "collaborations" do not count.
#  v4: a dated heading above a sentence dates it too; an intro line plus its bullet items counts as one line.)


def _rx(pattern: str) -> re.Pattern:
    return re.compile(pattern)


# ---- shared vocabulary (applied to FOLDED text: lowercase, no accents) ------------------------
INSTITUTION = _rx(
    r"\buniversit\w*|\bateneo\b|\bpolitecnic\w*|\bpolito\b|\bpolimi\b|\bunibo\b|\bunipd\b|\bunimore\b|\bunipr\b|"
    r"\bunitn\b|\bunibs\b|\bcnr\b|\benea\b|\binfn\b|\bcnrs\b|\bfraunhofer\b|\bhochschule\b|\bforschungs\w*|"
    r"\bistituto (?:nazionale|di ricerca|italiano|superiore|di tecnologia)\b|\bcentri? (?:di )?ricerca\b|"
    r"\bresearch (?:institute|center|centre|laborator\w*)\b|\bscuola superiore\b|\bsant'? ?anna\b|\bsissa\b|"
    r"\bpolo tecnologico\b|\bits academy\b|\bfondazione its\b|\beth\b|\bfondazione bruno kessler\b|\bfbk\b"
)
COLLAB_STRONG = _rx(
    r"collabor\w*|partnership|joint[- ](?:venture|development|research|project)|co-?svilupp\w*|co-?design|co-?creat\w*|"
    r"sviluppat\w* (?:insieme|in collaborazione|con)|in collaborazione con|insieme a\b|together with|in partnership with|"
    r"alleanz\w*|alliance|consorzi\w*|consortium|accordo (?:di|quadro|strategico|con)|progett\w* (?:di ricerca|europe\w*|finanziat\w*)|"
    r"horizon (?:2020|europe)|zusammenarbeit|kooperation|cooperazion\w*|cooperation"
)
COLLAB_FOR_UNI = _rx(
    COLLAB_STRONG.pattern + r"|\bprogett\w*|\bproject\w*|convenzion\w*|ricerca congiunta|laborator\w*|finanziat\w*|"
    r"research agreement|supporto scientifico|con il supporto|dottorat\w*|\bphd\b|\btesi\b|forschungsprojekt\w*|"
    r"\bcattedra\b|\bchair\b|spin-?off|\bborse? di (?:studio|ricerca)\b"
)
RECRUITING = _rx(
    r"lavora con noi|candidat\w*|curriculum|iscriv\w*|assunzion\w*|neolaureat\w*|offerte di lavoro|job opening|"
    r"apply now|posizioni aperte|open positions|stage curricular\w*|tirocin\w*"
)
# A collaboration with a training provider, a sponsor or an event organiser is not an innovation partner.
NOT_INNOVATION_PARTNER = _rx(
    r"formazion\w*|\bcors[oi]\b|\btraining\b|sponsor\w*|sponsorizz\w*|beneficen\w*|\bcharity\b|\bwebinar\b|"
    r"\bborse? di studio\b|\bfondo sociale\b|\bscuol[ae]\b"
)
ADDRESS_LIKE = _rx(r"\bvia\b[^.]{0,25}\buniversit|\bviale\b[^.]{0,25}\buniversit|\bpiazza\b[^.]{0,25}\buniversit|\bcorso\b[^.]{0,25}\buniversit")
COMMERCIAL_PARTNER = _rx(
    r"partner commercial\w*|commercial partner\w*|rete (?:di )?vendita|\brivenditor\w*|\bdistributor\w*|\bdealer\w*|"
    r"\bagent[ie]\b|clienti? e partner|partner e clienti"
)
PROGRAM = _rx(
    r"hackathon|accelerat\w*|start-?up (?:program\w*|challenge)|call for (?:ideas|start-?ups?|innovation)|open innovation|"
    r"innovation (?:challenge|award|contest|competition)|premio (?:per )?(?:l'? ?)?innovazione|premio innovazione|"
    r"concorso|corporate venturing|digital innovation hub|\bdih\b|competence cent\w*|incubat\w*|\bbando\b|"
    r"smau|premio (?:industria|impresa) 4\.0|industria 4\.0 award|top (?:of )?innovation"
)
PARTICIPATED = _rx(
    r"partecip\w*|particip\w*|vint[oaie]\b|vinc\w*|\bwon\b|winner|vincitor\w*|selezionat\w*|selected|finalist\w*|"
    r"ha aderito|aderi\w*|cohort|premiat\w*|\baward(?:ed)?\b|riconoscimento|menzione|\bmembro\b|\bmember\b|\bsocio\b"
)
EXPORT_WORD = _rx(
    r"\bexport\w*|\besport\w*|\bestero\b|\besteri\b|\babroad\b|foreign markets?|mercati (?:esteri|internazionali)|"
    r"\binternazional\w*|\bworldwide\b|all'estero|oltre confine|\bausland\b"
)
PERCENT = _rx(r"(\d{1,3}(?:[.,]\d{1,2})?)\s?(?:%|per ?cent\w*|per cento)")
GROWTH = _rx(
    r"cresc\w*|aument\w*|increment\w*|\bgrow\w*|increase\w*|rispetto a\w*|\bvs\b\.?|\+\s?\d|in crescita|\bcalo\b|"
    r"diminu\w*|riduz\w*|\bdecline\w*|\bstima\w*|obiettiv\w*|\btarget\b|\bentro il\b|\bpunta\b|\bpunt\w+ a\b"
)
SINCE_YEAR = _rx(r"(?:\bdal\b|\bdall'anno\b|\bfin dal\b|\bsin dal\b|\bgia dal\b|\bsince\b|\bseit\b)\s+(?:il\s+|l'anno\s+|anno\s+)?(19\d\d|20[0-2]\d)\b")

_STOP_ENTITIES = {
    "il", "la", "lo", "le", "gli", "i", "un", "una", "noi", "nostro", "nostra", "azienda", "societa", "gruppo", "italia",
    "europa", "italy", "europe", "the", "our", "we", "con", "per", "da", "in", "su", "nel", "nella", "dal", "dalla",
    "industria", "settore", "clienti", "cliente", "fornitori", "mercato", "mondo", "world", "global", "group", "company",
    "spa", "srl", "s.p.a.", "s.r.l.", "gmbh", "ag", "news", "home", "contatti", "chi", "siamo", "storia", "prodotti",
}
# Words that sit INSIDE a name ("Politecnico di Torino", "University of Padua"). "e", "and", "&"
# are deliberately absent: they join two separate partners, not one name.
_CONNECTORS = {"di", "del", "della", "dei", "degli", "dell'", "de", "of", "for", "delle", "dello"}


def named_entities(quote: str, exclude_tokens: Tuple[str, ...] = ()) -> List[str]:
    """Capitalised word sequences in `quote` (the counterparty candidates), skipping a lone
    sentence-initial word, generic words, and the company's own name."""
    tokens = re.findall(r"[A-Za-zÀ-ÿ0-9][\w&.'\-À-ÿ]*|&", quote)
    own = {fold(t) for t in exclude_tokens if t}
    entities: List[str] = []
    current: List[str] = []
    start_index = 0

    def flush():
        nonlocal current
        while current and fold(current[-1]) in _CONNECTORS:
            current = current[:-1]
        if current:
            name = " ".join(current)
            first_only = len(current) == 1 and start_index == 0
            words = [fold(w) for w in current]
            if not first_only and not all(w in _STOP_ENTITIES or w in own for w in words):
                entities.append(name)
        current = []

    for i, tok in enumerate(tokens):
        # A bare number ("4.0") is not a name; "3M" or "A2A" (digit + letters) can be.
        capital = tok[:1].isupper() or (tok[:1].isdigit() and any(c.isalpha() for c in tok))
        if capital and fold(tok) not in own:
            if not current:
                start_index = i
            current.append(tok)
        elif current and fold(tok) in _CONNECTORS:
            current.append(tok)
        else:
            flush()
    flush()
    return entities


@dataclass(frozen=True)
class Claim:
    id: str
    indicator: str
    weight: float
    description: str                       # goes into the model prompt
    triggers: re.Pattern                   # cheap pre-filter on folded text
    require: Tuple[re.Pattern, ...] = ()   # ALL must match the folded passage AND the folded quote
    reject: Optional[re.Pattern] = None    # any match in the folded quote rejects it
    mode: str = "llm"                      # "llm": model proposes, rules decide. "rules": rules only
    max_windows: int = 6
    stop_after_first: bool = True
    derive: Optional[Callable[[str, str, Dict[str, Any]], Optional[Dict[str, Any]]]] = field(default=None, compare=False)

    def passage_ok(self, passage: str) -> bool:
        f = fold(passage)
        if not self.triggers.search(f):
            return False
        return all(r.search(f) for r in self.require)

    def validate(self, quote: str, ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """None if the quote does not count; otherwise a dict of extra facts derived from it."""
        f = fold(quote)
        if len(quote) < 25 or len(quote) > 600:
            return None
        if not all(r.search(f) for r in self.require):
            return None
        if self.reject and self.reject.search(f):
            return None
        extra: Dict[str, Any] = {}
        if self.derive:
            derived = self.derive(quote, f, ctx)
            if derived is None:
                return None
            extra.update(derived)
        return extra


# ---- per-claim derivations -------------------------------------------------------------------
# A university partnership must NAME the institution. "Collaboriamo con universita e centri di ricerca"
# is a statement about the world in general, not a documented partnership: acronyms and proper names
# count on their own (CNR, Fraunhofer, Polito), a generic word needs a capitalised name after it
# ("Politecnico di Torino", "Universita degli Studi di Padova", "University of Bath").
NAMED_INSTITUTION = re.compile(
    r"\b(?:CNR|ENEA|INFN|CNRS|ETH|FBK|SISSA|Fraunhofer|Polito|Polimi|Unibo|Unipd|Unimore|Unipr|Unitn|Unibs)\b"
    r"|\bSant['’]? ?Anna\b"
    r"|\b(?:[Uu]niversit[àáaä]t?|[Uu]niversity|[Pp]olitecnic\w+|[Aa]teneo|[Hh]ochschule|[Ii]stituto|[Ii]nstitute|"
    r"[Ss]cuola [Ss]uperiore|[Cc]entro (?:di )?[Rr]icerca|[Rr]esearch (?:[Ii]nstitute|[Cc]ent(?:er|re)))"
    r"\s+(?:(?i:degli studi|di studi|di|del|della|dell['’]|of|the|für|fur|nazionale|italiano)\s+)*[A-Z0-9]"
)

# The partner must come right after the relation phrase and be capitalised. "In collaborazione con
# un importante system integrator" names nobody; "in collaborazione con Siemens Italia" does.
_REL_THEN_NAME = re.compile(
    r"(?:in collaborazione con|collaborazione con|collaborazione tra|collabor(?:a|ano|iamo|ato|ando|are)\s+con|"
    r"partnership con|partnership with|in partnership with|insieme a|insieme ad|together with|joint venture con|"
    r"joint venture with|joint venture tra|accordo con|accordo tra|sviluppat[oaie]\s+(?:con|insieme a|in collaborazione con)|"
    r"co-?sviluppat[oaie]\s+con|co-?svilupp\w*\s+con|alleanza con|cooperazione con|cooperation with|collaboration with|"
    r"consorzio|consortium|zusammenarbeit mit|in zusammenarbeit mit)\s+(?:il |lo |la |l['’]|i |gli |le |the )?",
    re.IGNORECASE,
)
_NAME_AT_START = re.compile(
    r"(?:[A-ZÀ-Ý][\w&.'’\-]*|\d+[A-Z][\w\-]*)"
    r"(?:\s+(?:(?:di|del|della|dei|degli|de|of|for)\s+)?[A-ZÀ-Ý][\w&.'’\-]*)*"
)


def partner_after_relation(quote: str, own_tokens: Tuple[str, ...] = ()) -> Optional[str]:
    own = {fold(t) for t in own_tokens if t}
    for m in _REL_THEN_NAME.finditer(quote):
        cand = _NAME_AT_START.match(quote, m.end())
        if not cand:
            continue
        name = cand.group(0).rstrip(".,;:-")
        words = [fold(w) for w in name.split()]
        if all(w in _STOP_ENTITIES or w in own for w in words):
            continue
        return name
    return None


def _derive_university(quote: str, f: str, ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if ADDRESS_LIKE.search(f):
        return None
    m = NAMED_INSTITUTION.search(quote)
    if not m:
        return None
    return {"institution_hint": quote[m.start(): m.start() + 70].split(",")[0].strip()}


def _derive_external(quote: str, f: str, ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if COMMERCIAL_PARTNER.search(f):
        return None
    partner = partner_after_relation(quote, tuple(ctx.get("own_name_tokens", ())))
    if not partner:
        return None
    return {"partner_hint": partner}


def _derive_open_innovation(quote: str, f: str, ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    m = PROGRAM.search(f)
    if not m:
        return None
    return {"program_hint": quote[m.start(): m.start() + 60].split(",")[0].strip()}


def _derive_export_share(quote: str, f: str, ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    # A share is a statement about NOW. "1997/05 ... export 70% of production" in a company-history
    # timeline is true of 1997 and says nothing about this year, so any year more than three years old
    # inside the quote disqualifies it.
    year_now = int(ctx.get("year_now") or datetime.now(timezone.utc).year)
    if any(int(y) <= year_now - 3 for y in re.findall(r"\b(19\d\d|20\d\d)\b", f)):
        return None
    heading = ctx.get("context_year")  # a dated heading on the line above (timeline pages)
    if heading and int(heading) <= year_now - 3:
        return None
    values = set()
    for m in PERCENT.finditer(f):
        window = f[max(0, m.start() - 90): m.end() + 90]
        if not EXPORT_WORD.search(window):
            continue
        near = f[max(0, m.start() - 45): m.end() + 45]
        if GROWTH.search(near):
            continue
        value = float(m.group(1).replace(",", "."))
        if 0 < value <= 100:
            values.add(value)
    if len(values) != 1:  # none valid, or several different figures: ambiguous, do not guess
        return None
    return {"value": values.pop()}


def _derive_export_since(quote: str, f: str, ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    year_now = int(ctx.get("year_now") or datetime.now(timezone.utc).year)
    years = set()
    for m in SINCE_YEAR.finditer(f):
        year = int(m.group(1))
        around = f[max(0, m.start() - 100): m.end() + 100]
        if EXPORT_WORD.search(around) and 1900 <= year <= year_now:
            years.add(year)
    if len(years) != 1:
        return None
    return {"value": float(years.pop())}


CLAIMS: Dict[str, Claim] = {c.id: c for c in [
    Claim(
        id="university_partnership", indicator="university_partnership", weight=5.0,
        description=("has a collaboration, joint research project, research agreement, shared laboratory, industrial PhD "
                     "or partnership with a named university, polytechnic or public research institute"),
        triggers=INSTITUTION, require=(INSTITUTION, COLLAB_FOR_UNI), reject=RECRUITING,
        derive=_derive_university, max_windows=6,
    ),
    Claim(
        id="external_collaboration", indicator="external_collaboration", weight=5.0,
        description=("develops products or technology together with a named external partner (a company, startup, consortium "
                     "or research body) through a collaboration, partnership, joint development or joint venture. "
                     "Ordinary customers, dealers and distributors do not count"),
        triggers=COLLAB_STRONG, require=(COLLAB_STRONG,),
        reject=_rx(RECRUITING.pattern + "|" + NOT_INNOVATION_PARTNER.pattern),
        derive=_derive_external, max_windows=6,
    ),
    Claim(
        id="open_innovation", indicator="prior_open_innovation_usage", weight=4.0,
        description=("took part in, won, or was selected for a named innovation competition, accelerator, hackathon, "
                     "open-innovation call or innovation award"),
        triggers=PROGRAM, require=(PROGRAM, PARTICIPATED), reject=RECRUITING,
        derive=_derive_open_innovation, max_windows=4,
    ),
    Claim(
        id="export_share_pct", indicator="international_sales_volume", weight=3.0,
        description=("states what percentage of its sales, turnover or production goes to foreign markets "
                     "(a share of the total, not a growth rate)"),
        triggers=PERCENT, require=(PERCENT, EXPORT_WORD), reject=None,
        derive=_derive_export_share, max_windows=4,
    ),
    Claim(
        id="export_since_year", indicator="years_international_activity", weight=2.0,
        description="states the year since which the company has exported or sold abroad",
        triggers=SINCE_YEAR, require=(SINCE_YEAR, EXPORT_WORD), reject=None, mode="rules",
        derive=_derive_export_since, max_windows=4,
    ),
]}
CLAIM_ORDER: List[str] = sorted(CLAIMS, key=lambda k: -CLAIMS[k].weight)
