// Vienna Crawler Worker — runs the Vienna crawlers on this computer when the Vienna app asks.
//
// It holds no database password. It only knows the worker_shim/ service's URL and its own
// token, and talks to three token-checked functions (worker/supabase_rpc.sql on the server)
// through that shim:
//   heartbeat  every ~15s: "I'm here" + version + self-test results (this is how the app
//              knows the install is present, current and healthy)
//   claim      every ~2s while it has a free slot: "give me my next queued crawl"
//   complete   posts the crawl's rows (or its error) back
//
// Everything is Node built-ins — nothing to install for the worker itself.
//
//   node worker.mjs              run the worker (what the startup shortcut does)
//   node worker.mjs --selftest   check the installation and print a report (used by the installer)

import fs from 'node:fs';
import crypto from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = process.env.VIENNA_WORKER_HOME ? path.resolve(process.env.VIENNA_WORKER_HOME) : path.resolve(HERE, '..');
const CRAWLERS_DIR = path.join(ROOT, 'crawlers');
const BROWSERS_DIR = path.join(ROOT, 'browsers');
const LOG_FILE = path.join(ROOT, 'worker.log');
const STATUS_FILE = path.join(ROOT, 'status.json');
const UPDATE_FAILURE_FILE = path.join(ROOT, 'update-failure.json');
const LOCK_PORT_FILE = path.join(ROOT, 'worker.pid');

const HEARTBEAT_MS = 15_000;
const CLAIM_MS = 2_000;
const SELFTEST_EVERY_MS = 30 * 60_000;
const RPC_TIMEOUT_MS = 25_000;
const UPDATE_CHECK_MS = 5 * 60_000;
const PROTOCOL = 1;

// Crawler subprocesses may only receive these settings from the app. The task queue is
// trusted, but a worker should still never let it inject things like NODE_OPTIONS or PATH.
const ENV_ALLOWLIST = new Set([
  'LLM_API_KEY', 'LLM_BASE_URL', 'LLM_MODEL', 'WAYBACK_DELAY_MS', 'SEARCH_PROVIDER',
  'NEWSAPI_KEY', 'ANTHROPIC_API_KEY', 'BUILTWITH_API_KEY', 'LINKEDIN_LI_AT',
  // Wall-clock the crawler may use before it must hand back what it has (set a little under the
  // kill timeout), and the optional second LLM provider used when the first is rate-limited.
  'SOFT_DEADLINE_SECONDS', 'LLM_FALLBACK_API_KEY', 'LLM_FALLBACK_BASE_URL', 'LLM_FALLBACK_MODEL',
  'LLM_REASONING_EFFORT',
  // digital-maturity-crawler's visual-assessment phase (2026-10-08) — a separate provider
  // namespace from LLM_* above, see config.py's CRAWLER_VISION_LLM_* docstring. Same
  // primary + one-fallback coverage as the LLM_* entries; without these, that phase's calls
  // get silently stripped to nothing on a remote worker and visual_assessment reads not_found
  // for every company it runs there, with no error surfaced.
  'VISION_LLM_API_KEY', 'VISION_LLM_BASE_URL', 'VISION_LLM_MODEL',
  'VISION_LLM_FALLBACK_API_KEY', 'VISION_LLM_FALLBACK_BASE_URL', 'VISION_LLM_FALLBACK_MODEL',
]);

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''));
}

let CONFIG;
let VERSION_INFO;
try {
  CONFIG = readJson(path.join(ROOT, 'worker.config.json'));
  VERSION_INFO = readJson(path.join(ROOT, 'VERSION.json'));
} catch (e) {
  console.error(`Vienna Crawler Worker is not installed correctly (${e.message}). Run the setup file again.`);
  process.exit(2);
}

// ---- logging ---------------------------------------------------------------------------

function log(msg) {
  const line = `${new Date().toISOString()}  ${msg}`;
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch { /* logging must never crash the worker */ }
  if (process.stdout.isTTY) console.log(line);
}

function trimLog() {
  try {
    if (fs.statSync(LOG_FILE).size > 2_000_000) fs.renameSync(LOG_FILE, LOG_FILE + '.old');
  } catch { /* no log yet */ }
}

function removeRetiredInstallations() {
  const parent = path.dirname(ROOT);
  const prefix = `${path.basename(ROOT)}-retired-`;
  try {
    for (const name of fs.readdirSync(parent)) {
      if (name.startsWith(prefix)) {
        // The updater still needs an uncommitted backup for rollback. It marks a
        // leftover folder only after the replacement has connected and passed tests.
        if (!fs.existsSync(path.join(parent, name, '.vienna-update-complete'))) continue;
        try { fs.rmSync(path.join(parent, name), { recursive: true, force: true }); }
        catch (e) { log(`could not yet remove retired installation '${name}': ${e.message}`); }
      }
    }
  } catch { /* cleanup is best effort and must never stop the worker */ }
}

function writeStatus(patch) {
  let cur = {};
  try { cur = readJson(STATUS_FILE); } catch { /* first write */ }
  try { fs.writeFileSync(STATUS_FILE, JSON.stringify({ ...cur, ...patch }, null, 2)); } catch { /* best effort */ }
}

function updateFailure() {
  try { return readJson(UPDATE_FAILURE_FILE); } catch { return null; }
}

function recordUpdateFailure(message) {
  const failure = { message: String(message).slice(0, 300), at: new Date().toISOString() };
  try { fs.writeFileSync(UPDATE_FAILURE_FILE, JSON.stringify(failure)); } catch { /* best effort */ }
  writeStatus({ state: 'connected', updateError: failure.message });
}

// ---- talking to the server -----------------------------------------------------------------

async function rpc(fn, args) {
  const res = await fetch(`${CONFIG.shimUrl.replace(/\/$/, '')}/rpc/${fn}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(args), signal: AbortSignal.timeout(RPC_TIMEOUT_MS),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`${fn} -> HTTP ${res.status} ${body.slice(0, 300)}`);
  return body ? JSON.parse(body) : null;
}

async function fetchJson(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(RPC_TIMEOUT_MS) });
  const body = await res.text();
  if (!res.ok) throw new Error(`HTTP ${res.status} ${body.slice(0, 300)}`);
  return JSON.parse(body);
}

async function startUpdate(manifest, workerInfo) {
  const reportProgress = async (progress) => {
    writeStatus({ state: 'updating', updateProgress: progress });
    try {
      await rpc('vienna_worker_heartbeat', { p_token: CONFIG.token, p_info: {
        ...workerInfo, update_state: 'updating', target_build: manifest.build,
        update_progress: progress,
      } });
    } catch (e) { log(`could not report update progress: ${String(e.message).slice(0, 200)}`); }
  };
  await reportProgress({ stage: 'downloading', label: 'Downloading crawler update', percent: 0, downloaded_bytes: 0, total_bytes: null });
  const download = await fetch(manifest.download_url, { signal: AbortSignal.timeout(120_000) });
  if (!download.ok) throw new Error(`update download -> HTTP ${download.status}`);
  const totalBytes = Number(download.headers.get('content-length')) || Number(manifest.size_bytes) || null;
  const reader = download.body?.getReader();
  if (!reader) throw new Error('update download returned no response body');
  const chunks = [];
  let downloadedBytes = 0;
  let lastReported = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(Buffer.from(value));
    downloadedBytes += value.byteLength;
    if (downloadedBytes > 100 * 1024 * 1024) throw new Error('update bundle is unexpectedly large');
    if (Date.now() - lastReported >= 700) {
      const percent = totalBytes ? Math.min(29, Math.floor(downloadedBytes / totalBytes * 29)) : null;
      await reportProgress({ stage: 'downloading', label: 'Downloading crawler update', percent,
        downloaded_bytes: downloadedBytes, total_bytes: totalBytes });
      lastReported = Date.now();
    }
  }
  const bytes = Buffer.concat(chunks);
  if (bytes.length > 100 * 1024 * 1024) throw new Error('update bundle is unexpectedly large');
  await reportProgress({ stage: 'verifying', label: 'Checking downloaded update', percent: 30,
    downloaded_bytes: bytes.length, total_bytes: totalBytes || bytes.length });
  const actual = crypto.createHash('sha256').update(bytes).digest('hex');
  if (actual !== manifest.sha256) throw new Error('update bundle failed checksum verification');

  const nonce = crypto.randomUUID();
  const zipPath = path.join(os.tmpdir(), `vienna-update-${nonce}.zip`);
  const updaterPath = path.join(os.tmpdir(), `vienna-update-${nonce}.ps1`);
  fs.writeFileSync(zipPath, bytes);
  fs.copyFileSync(path.join(HERE, 'update.ps1'), updaterPath);
  writeStatus({ state: 'updating', fromBuild: VERSION_INFO.build, toBuild: manifest.build,
    startedAt: new Date().toISOString(), updateProgress: { stage: 'starting', label: 'Starting installer', percent: 32 } });
  await rpc('vienna_worker_heartbeat', { p_token: CONFIG.token, p_info: {
    ...workerInfo, update_state: 'updating', target_build: manifest.build,
    update_progress: { stage: 'starting', label: 'Starting installer', percent: 32 },
  } });
  log(`update ${VERSION_INFO.build} -> ${manifest.build} downloaded and verified; handing over to updater`);

  const child = spawn('powershell.exe', [
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', updaterPath,
    '-Dir', ROOT, '-ZipPath', zipPath, '-ExpectedBuild', manifest.build,
    '-ParentPid', String(process.pid), '-WorkerInfoBase64', Buffer.from(JSON.stringify(workerInfo)).toString('base64'),
  ], { detached: true, windowsHide: true, stdio: 'ignore' });
  await new Promise((resolve, reject) => {
    child.once('spawn', resolve);
    child.once('error', reject);
  });
  child.unref();
  process.exit(0);
}

// ---- self-test ---------------------------------------------------------------------------------

function entryFor(crawler) {
  return fs.existsSync(path.join(CRAWLERS_DIR, crawler, 'src', 'main.mjs')) &&
    !fs.existsSync(path.join(CRAWLERS_DIR, crawler, 'dist', 'main.js'))
    ? path.join('src', 'main.mjs') : path.join('dist', 'main.js');
}

async function selfTest({ launchBrowser = true } = {}) {
  const checks = {};
  const major = Number(process.versions.node.split('.')[0]);
  checks.node = { ok: major >= 18, detail: `Node ${process.versions.node}${major >= 18 ? '' : ' (needs 18 or newer)'}` };

  const missing = [];
  for (const c of VERSION_INFO.crawlers || []) {
    if (!fs.existsSync(path.join(CRAWLERS_DIR, c, entryFor(c)))) missing.push(c);
  }
  const depsOk = fs.existsSync(path.join(CRAWLERS_DIR, 'node_modules', 'crawlee', 'package.json'));
  checks.crawlers = {
    ok: missing.length === 0 && depsOk,
    detail: missing.length ? `missing: ${missing.join(', ')}` : depsOk ? `${(VERSION_INFO.crawlers || []).length} crawlers present`
      : 'crawler libraries (node_modules) are missing',
  };

  process.env.PLAYWRIGHT_BROWSERS_PATH = BROWSERS_DIR;
  try {
    const { chromium } = createRequire(path.join(CRAWLERS_DIR, 'package.json'))('playwright');
    const exe = chromium.executablePath();
    if (!fs.existsSync(exe)) {
      checks.browser = { ok: false, detail: 'the headless browser is not installed' };
    } else if (!launchBrowser) {
      checks.browser = { ok: true, detail: 'browser present' };
    } else {
      const b = await chromium.launch({ headless: true });
      const version = b.version();
      await b.close();
      checks.browser = { ok: true, detail: `Chromium ${version} starts` };
    }
  } catch (e) {
    checks.browser = { ok: false, detail: `browser check failed: ${String(e.message).split('\n')[0].slice(0, 200)}` };
  }
  return { at: new Date().toISOString(), checks, ok: Object.values(checks).every((c) => c.ok) };
}

function printReport(report) {
  for (const [name, c] of Object.entries(report.checks)) console.log(`  ${c.ok ? '[ ok ]' : '[FAIL]'} ${name}: ${c.detail}`);
}

// ---- running a task ----------------------------------------------------------------------------

function killTree(child) {
  try {
    if (process.platform === 'win32') spawnSync('taskkill', ['/F', '/T', '/PID', String(child.pid)], { windowsHide: true });
    else process.kill(-child.pid, 'SIGKILL');
  } catch { /* already gone */ }
  try { child.kill('SIGKILL'); } catch { /* already gone */ }
}

function readDataset(dir) {
  if (!fs.existsSync(dir)) return [];
  const rows = [];
  for (const f of fs.readdirSync(dir).filter((n) => n.endsWith('.json')).sort()) {
    try { rows.push(JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'))); } catch { /* skip a torn file */ }
  }
  return rows;
}

function safeEnv(requested) {
  const env = {};
  for (const [k, v] of Object.entries(requested || {})) {
    if (ENV_ALLOWLIST.has(k)) env[k] = String(v);
  }
  return env;
}

function runProcess(args, cwd, env, timeoutSec) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, args, {
      cwd, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], detached: process.platform !== 'win32',
    });
    let out = '';
    const keep = (d) => { out = (out + d.toString('utf8')).slice(-4000); };
    child.stdout.on('data', keep);
    child.stderr.on('data', keep);
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; killTree(child); }, timeoutSec * 1000);
    child.on('error', (e) => { clearTimeout(timer); resolve({ code: -1, out: String(e), timedOut }); });
    child.on('close', (code) => { clearTimeout(timer); resolve({ code, out, timedOut }); });
  });
}

async function runTask(task) {
  const { crawler, kind, request } = task;
  const known = new Set(VERSION_INFO.crawlers || []);
  if (!/^[a-z0-9-]+$/.test(crawler) || !known.has(crawler)) throw new Error(`unknown crawler '${crawler}'`);
  const dir = path.join(CRAWLERS_DIR, crawler);
  if (!fs.existsSync(dir)) throw new Error(`crawler folder missing: ${crawler}`);

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), `vienna_${crawler.replace(/-/g, '_')}_`));
  try {
    const env = {
      ...process.env,
      PLAYWRIGHT_BROWSERS_PATH: BROWSERS_DIR,
      CRAWLEE_STORAGE_DIR: path.join(tmp, 'storage'),
      ...safeEnv(request.env),
    };
    const extra = (request.extra_args || []).map(String);
    let args;
    if (kind === 'csv') {
      const input = path.join(tmp, 'input.csv');
      fs.writeFileSync(input, request.input_csv, 'utf8');
      args = [path.join('dist', 'main.js'), input, ...extra];
    } else if (kind === 'node') {
      const entry = String(request.entry || '');
      const resolved = path.resolve(dir, entry);
      if (!entry || path.isAbsolute(entry) || !resolved.startsWith(dir + path.sep)) throw new Error(`bad entry '${entry}'`);
      args = [entry, ...(request.cli_args || []).map(String)];
    } else {
      throw new Error(`unknown task kind '${kind}'`);
    }

    const timeout = Math.max(10, Math.min(Number(request.timeout) || 90, 900));
    const { code, out, timedOut } = await runProcess(args, dir, env, timeout);
    if (timedOut) throw new Error(`${crawler} timed out after ${timeout}s`);
    if (code !== 0) throw new Error(`${crawler} exited ${code}: ${out.slice(-1500)}`);
    return readDataset(path.join(tmp, 'storage', 'datasets', 'default'));
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

// ---- main loop -----------------------------------------------------------------------------------

function acquireSingleInstance() {
  // A second copy (e.g. the startup entry plus a manual launch) would only fight over tasks;
  // the pid file makes the newer one exit quietly.
  try {
    const pid = Number(fs.readFileSync(LOCK_PORT_FILE, 'utf8'));
    if (pid && pid !== process.pid) {
      try { process.kill(pid, 0); return false; } catch { /* stale pid file */ }
    }
  } catch { /* no pid file */ }
  fs.writeFileSync(LOCK_PORT_FILE, String(process.pid));
  return true;
}

async function main() {
  trimLog();
  if (process.argv.includes('--selftest')) {
    console.log(`Checking the installation (build ${VERSION_INFO.build})...`);
    const report = await selfTest();
    printReport(report);
    writeStatus({ selftest: report });
    process.exit(report.ok ? 0 : 1);
  }

  if (!acquireSingleInstance()) { log('another worker is already running — exiting'); process.exit(0); }
  const cleanup = () => { try { fs.rmSync(LOCK_PORT_FILE, { force: true }); } catch { /* ignore */ } };
  process.on('exit', cleanup);
  process.on('SIGINT', () => process.exit(0));
  process.on('SIGTERM', () => process.exit(0));

  const maxParallel = Math.max(1, Math.min(Number(CONFIG.maxParallel) || 4, 8));
  let running = 0;
  let selfTestReport = await selfTest();
  let selfTestAt = Date.now();
  log(`worker ${VERSION_INFO.version} (build ${VERSION_INFO.build}) starting as '${CONFIG.name}'; self-test ${selfTestReport.ok ? 'passed' : 'FAILED'}`);

  const info = () => {
    const failure = updateFailure();
    return {
      protocol: PROTOCOL, version: VERSION_INFO.version, build: VERSION_INFO.build,
      node: process.versions.node, os: `${os.platform()} ${os.release()}`, host: os.hostname(),
      busy: running, max_parallel: maxParallel, checks: selfTestReport.checks, selftest_at: selfTestReport.at,
      auto_update: true,
      ...(failure ? { update_error: failure } : {}),
    };
  };

  let lastBeat = 0;
  let lastUpdateCheck = 0;
  let lastUpdateError = '';
  let connected = false;
  let lastConnectionError = '';
  const beat = async () => {
    const r = await rpc('vienna_worker_heartbeat', { p_token: CONFIG.token, p_info: info() });
    lastBeat = Date.now();
    if (!r || r.ok === false) {
      log(`server refused this worker (${r && r.reason}); it was removed in the app — stopping`);
      writeStatus({ state: 'revoked' });
      process.exit(0);
    }
    if (!connected) {
      connected = true;
      lastConnectionError = '';
      log('connected to Vienna');
      removeRetiredInstallations();
    }
    writeStatus({ state: 'connected', lastHeartbeat: new Date().toISOString(), selftest: selfTestReport });
  };

  const execute = async (task) => {
    running += 1;
    log(`task ${task.id}: ${task.crawler} started`);
    try {
      const rows = await runTask(task);
      await rpc('vienna_worker_complete', { p_token: CONFIG.token, p_task_id: task.id, p_ok: true, p_result: { rows }, p_error: null });
      log(`task ${task.id}: ${task.crawler} done (${rows.length} rows)`);
    } catch (e) {
      log(`task ${task.id}: ${task.crawler} failed: ${String(e.message).slice(0, 300)}`);
      try {
        await rpc('vienna_worker_complete', { p_token: CONFIG.token, p_task_id: task.id, p_ok: false, p_result: null, p_error: String(e.message).slice(0, 3900) });
      } catch (e2) { log(`task ${task.id}: could not report the failure: ${e2.message}`); }
    } finally {
      running -= 1;
    }
  };

  for (;;) {
    try {
      if (Date.now() - lastBeat >= HEARTBEAT_MS) await beat();
      if (Date.now() - selfTestAt >= SELFTEST_EVERY_MS && running === 0) {
        selfTestReport = await selfTest();
        selfTestAt = Date.now();
        lastBeat = 0; // report the fresh result straight away
      }
      if (running === 0 && Date.now() - lastUpdateCheck >= UPDATE_CHECK_MS) {
        lastUpdateCheck = Date.now();
        try {
          const base = CONFIG.shimUrl.replace(/\/$/, '');
          const manifest = await fetchJson(`${base}/update/latest`);
          if (!manifest.build || !manifest.sha256 || !manifest.download_url) {
            throw new Error('update service returned an incomplete manifest');
          }
          if (manifest.build !== VERSION_INFO.build) await startUpdate(manifest, info());
          fs.rmSync(UPDATE_FAILURE_FILE, { force: true });
          lastUpdateError = '';
        } catch (e) {
          const message = String(e.message).slice(0, 300);
          if (message !== lastUpdateError) log(`update check failed (normal work continues): ${message}`);
          lastUpdateError = message;
          recordUpdateFailure(message);
        }
      }
      while (running < maxParallel) {
        const r = await rpc('vienna_worker_claim', { p_token: CONFIG.token });
        if (!r || r.ok === false) throw new Error(`claim refused: ${r && r.reason}`);
        if (!r.task) break;
        void execute(r.task);
      }
    } catch (e) {
      const message = String(e.message).slice(0, 300);
      // Log the first failure as well as any change in the failure. Previously initial
      // failures were completely invisible, which made a bad or stale configuration look
      // like an ordinary offline computer forever.
      if (connected || message !== lastConnectionError) {
        log(`connection problem (will keep retrying): ${message}`);
        lastConnectionError = message;
      }
      writeStatus({ state: 'retrying', lastError: message, lastAttempt: new Date().toISOString() });
      connected = false;
    }
    await new Promise((r) => setTimeout(r, CLAIM_MS));
  }
}

main().catch((e) => { log(`fatal: ${e.stack || e}`); process.exit(1); });
