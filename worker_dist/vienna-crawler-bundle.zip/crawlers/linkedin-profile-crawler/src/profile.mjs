/** Shared by the crawler and browser-fixture regressions. */
export async function isAccessBlocked(page) {
    const pathname = new URL(page.url()).pathname;
    if (/^\/(?:checkpoint|login|authwall|uas\/login)(?:\/|$)/i.test(pathname)) return true;
    return page.locator('input[name="session_key"], form[action*="login-submit"]')
        .first().isVisible().catch(() => false);
}

export async function extractProfile(page, url) {
    async function text(selector) {
        const element = page.locator(selector).first();
        return await element.count() ? (await element.innerText()).trim() || null : null;
    }
    const name = await text('h1.text-heading-xlarge, h1.top-card-layout__title');
    const headline = await text('div.text-body-medium, h2.top-card-layout__headline');
    const location = await text('span.text-body-small.inline.t-black--light, span.top-card__subline-item');
    const about = await text('section:has(#about) div.inline-show-more-text, section.summary div.core-section-container__content');
    const experience = await text('section:has(#experience) li.artdeco-list__item, section.experience li.experience-item');
    const recentRole = experience?.replace(/\n+/g, ' | ') ?? null;
    return {
        url, name, headline, location, about, recentRole,
        status: name ? 'SUCCESS' : 'PROFILE_NOT_FOUND',
        scrapedAt: new Date().toISOString(),
    };
}

export async function handleFailedRequest({ request, log, pushData }, error) {
    const message = error instanceof Error ? error.message : String(error);
    log.error(`Request ${request.url} failed completely: ${message}`);
    await pushData({
        url: request.url,
        status: 'FAILED',
        error: message,
        scrapedAt: new Date().toISOString(),
    });
}

export function readProfileUrls(args) {
    const defaults = [
        'https://www.linkedin.com/in/satyanadella/',
        'https://www.linkedin.com/in/williamhgates/',
    ];
    const urls = args.length ? args : defaults;
    const normalized = [...new Set(urls.map((input) => {
        const url = new URL(input.trim());
        if (url.protocol !== 'https:' || !/(^|\.)linkedin\.com$/i.test(url.hostname) ||
            !/^\/in\/[^/]+\/?$/.test(url.pathname) || url.username || url.password || url.port) {
            throw new Error(`Expected an HTTPS LinkedIn /in/ profile URL: ${input}`);
        }
        url.search = '';
        url.hash = '';
        url.pathname = `${url.pathname.replace(/\/$/, '')}/`;
        return url.toString();
    }))];
    if (normalized.length > 20) throw new Error('At most 20 unique profiles can be crawled per run; split the input into batches.');
    return normalized;
}
