import { PlaywrightCrawler, ProxyConfiguration } from 'crawlee';
import dotenv from 'dotenv';
import { extractProfile, handleFailedRequest, isAccessBlocked, readProfileUrls } from './profile.mjs';

dotenv.config();
const seedUrls = readProfileUrls(process.argv.slice(2));

// 1. Session Credentials & Configuration
const LINKEDIN_LI_AT = process.env.LINKEDIN_LI_AT;
const LINKEDIN_JSESSIONID = process.env.LINKEDIN_JSESSIONID;
const PROXY_URL = process.env.PROXY_URL;

if (!LINKEDIN_LI_AT) {
    console.warn(
        '[WARNING] LINKEDIN_LI_AT is not set in environment or .env file. ' +
        'Scraping will proceed as an unauthenticated guest and will hit login walls quickly.'
    );
}

// 2. Proxy Configuration (Optional but recommended for scale)
let proxyConfiguration;
if (PROXY_URL) {
    proxyConfiguration = new ProxyConfiguration({
        proxyUrls: [PROXY_URL],
    });
}

// 3. Helper for random human delays
const sleep = (minMs, maxMs) => {
    const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
    return new Promise((resolve) => setTimeout(resolve, delay));
};

// 4. Initialize PlaywrightCrawler
const crawler = new PlaywrightCrawler({
    proxyConfiguration,
    // Keep concurrency strictly at 1 to mimic normal human browsing and avoid checkpoints
    maxConcurrency: 1,
    maxRequestsPerCrawl: 20,
    navigationTimeoutSecs: 60,
    requestHandlerTimeoutSecs: 180,

    // Headless mode (set headless: false if you want to visually observe the browser)
    headless: true,

    // Pre-navigation hook: inject authenticated cookies before page loads
    preNavigationHooks: [
        async ({ page, log }) => {
            if (LINKEDIN_LI_AT) {
                const cookies = [
                    {
                        name: 'li_at',
                        value: LINKEDIN_LI_AT,
                        domain: '.linkedin.com',
                        path: '/',
                        httpOnly: true,
                        secure: true,
                    },
                ];

                if (LINKEDIN_JSESSIONID) {
                    cookies.push({
                        name: 'JSESSIONID',
                        value: LINKEDIN_JSESSIONID.replace(/^"|"$/g, ''),
                        domain: '.linkedin.com',
                        path: '/',
                        httpOnly: false,
                        secure: true,
                    });
                }

                await page.context().addCookies(cookies);
                log.info('Successfully injected LinkedIn session cookies.');
            }
        },
    ],

    // Request Handler: process each crawled page
    async requestHandler({ request, page, pushData, log }) {
        log.info(`Processing URL: ${request.loadedUrl}`);

        // Check for login wall or checkpoint redirect
        const currentUrl = page.url();
        if (await isAccessBlocked(page)) {
            log.error(`Hit login wall / verification checkpoint at: ${currentUrl}`);
            await pushData({
                url: request.url,
                status: 'BLOCKED_BY_CHECKPOINT',
                redirectUrl: currentUrl,
                scrapedAt: new Date().toISOString(),
            });
            return;
        }

        // Wait for main content to appear
        await page.waitForLoadState('domcontentloaded');
        await sleep(2000, 3500);

        // Smoothly scroll down to trigger lazy loading of profile sections
        log.info('Scrolling page to trigger dynamic content loading...');
        await page.evaluate(async () => {
            await new Promise((resolve) => {
                let totalHeight = 0;
                const distance = 400;
                const timer = setInterval(() => {
                    const scrollHeight = document.body.scrollHeight;
                    window.scrollBy(0, distance);
                    totalHeight += distance;

                    if (totalHeight >= scrollHeight || totalHeight > 4000) {
                        clearInterval(timer);
                        resolve();
                    }
                }, 250);
            });
        });

        await sleep(1500, 2500);

        // Click any inline "see more" / expansion buttons if available
        try {
            const seeMoreButtons = page.locator('button.inline-show-more-text__button, button[aria-label*="see more"]');
            const count = await seeMoreButtons.count();
            for (let i = 0; i < Math.min(count, 3); i++) {
                if (await seeMoreButtons.nth(i).isVisible()) {
                    await seeMoreButtons.nth(i).click({ timeout: 1000 }).catch(() => {});
                }
            }
        } catch (err) {
            // Ignore minor click failures
        }

        const profileData = await extractProfile(page, request.loadedUrl ?? request.url);
        log.info(`Extracted profile data for: "${profileData.name || 'Unknown'}" (${profileData.status})`);

        // Save result as JSON in ./storage/datasets/default
        await pushData(profileData);

        // Add a randomized delay before the next request in queue
        await sleep(3000, 6000);
    },

    // Handle failed requests
    failedRequestHandler: handleFailedRequest,
});

console.log(`Starting crawl on ${seedUrls.length} target URLs...`);
await crawler.run(seedUrls);

// 6. Export Dataset to CSV
try {
    await crawler.exportData('./result.csv');
    console.log('Successfully exported results to ./result.csv');
} catch (err) {
    console.warn(`Export to CSV notice: ${err.message}`);
    process.exitCode = 1;
}

// 7. Preview output in terminal
const data = await crawler.getData();
console.table(data.items);
